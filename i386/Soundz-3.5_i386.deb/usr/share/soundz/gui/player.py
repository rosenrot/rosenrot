# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME
import gtk

from utils import prefs

class GtkDialog(gtk.Window):

    def __init__(self, widget, width, height):
        gtk.Window.__init__(self)

        self.add(widget)
        self.connect('delete-event', self.destroy)

        self.set_size_request(width, height)
        self.set_resizable(False)

        self.set_modal(True)
        self.set_skip_taskbar_hint(True)
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DIALOG)
        self.set_transient_for(prefs.Window)
        self.set_position(gtk.WIN_POS_CENTER_ON_PARENT)
        #elf.set_position(gtk.WIN_POS_MOUSE)
        #self.set_opacity(0.95)

    def add(self, widget):
        try:
            widget.unparent()
        finally:
            gtk.Window.add(self, widget)
        widget.reparent(self)
        widget.show_all()

    def destroy(self, window, event):
        self.hide()
        return True

class GtkAbout(GtkDialog):

    def __init__(self):
        btn = gtk.EventBox()
        btn.set_visible_window(False)
        btn.add(gtk.image_new_from_file(prefs.pixPath('gtk-close.png')))
        btn.connect('button-press-event', self.destroy)
        hbox = gtk.HBox()
        hbox.set_border_width(2)
        hbox.pack_end(btn, False, False, 0)

        vbox = gtk.VBox()
        for w in (
            gtk.image_new_from_file(prefs.pixPath('48.png')),
            gtk.image_new_from_file(prefs.pixPath('160.png')),
            gtk.Label('mickyz.deviantart.com'),
            gtk.Label('(c)2012'),
            ):
            vbox.pack_start(w, True, True, 0)
        vbox.set_border_width(12)
        ebox = gtk.EventBox()
        ebox.add(vbox)
        vbox = gtk.VBox()
        vbox.pack_start(hbox, False, True, 0)
        vbox.add(ebox)

        GtkDialog(vbox, 240, -1)

class GtkWindow(gtk.Window):

    about = None
    _size = 520,300

    def __init__(self):
        gtk.Window.__init__(self)

        prefs.Window = self
        widget = prefs.getWidget()
        try:
            widget.unparent()
        finally:
            gtk.Window.add(self, widget)
        widget.reparent(self)
        widget.show_all()

        if prefs.get('window-maximize', False):
            self.maximize()
        else:
            size = prefs.get('window-size', self._size)
            self.resize(*size)
        #self.move(*prefs.get('window-position', (0,0)))
        self.set_position(gtk.WIN_POS_CENTER)

        self.set_icon_from_file(prefs.iconExec)
        self.set_role(prefs.appExec)
        self.set_title(prefs.appExec.title())

        self.show_all()

        self.connect('delete-event', self.onQuit)

        status = prefs.getWidget('evt-status')
        status.connect('button-press-event',
            lambda w,e: self.begin_resize_drag(gtk.gdk.WINDOW_EDGE_SOUTH_EAST,
            e.button, int(e.x_root), int(e.y_root), e.get_time())
            if e.button == 1 else self.resize(*self._size) )

        self.onStart()

    def onStart(self):
        """ Start the modules and the GTK main loop """
        import mods
        mods.postMsg(mods.MSG_APP_STARTED)

        gtk.main()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def __connect_hbox(self, widget, event):
        self.set_decorated(False)

        menu = prefs.getWidget('btn-menu')
        menu.connect('button-press-event', self.menu_popup)
        close = prefs.getWidget('btn-close')
        close.connect('button-press-event',
            lambda w,e: self.emit('delete-event', gtk.gdk.Event(gtk.gdk.DELETE)))
        title = prefs.getWidget('evt-title')
        title.connect('button-press-event', self.__connect_motion)
        title.connect('button-release-event', self.button_release)

    def __connect_motion(self, widget, event):
        if event.button <= 1:
            self._pt = widget.connect('motion-notify-event', self.motion_notify)
            self._px, self._py = self.get_position()
            self._px = event.x_root - self._px
            self._py = event.y_root - self._py

    def button_press(self, widget, event):
        if event.button <= 1:
            self.__connect_motion(widget, event)

    def button_release(self, widget, event):
        if event.button <= 1 and self._pt:
            widget.disconnect(self._pt)
            self._pt = None

    def motion_notify(self, widget, event):
        self.move(int(event.x_root -self._px), int(event.y_root -self._py))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onAbout(self):
        """ Show the about dialog """
        if not self.about:
            from gui.abt import About
            self.about = About()
        self.about.show()

    def onBusy(self, pending=True):
        """ Show a waiting cursor when pending events """
        self.window.set_cursor(gtk.gdk.Cursor(gtk.gdk.WATCH) \
            if pending else None)
        #while gtk.events_pending():
        #   gtk.main_iteration(False)

    def onIconify(self, icon=None):
        """ Iconify the window to a StatusIcon """
        state = self.window.get_state()
        is_icon = state == gtk.gdk.WINDOW_STATE_ICONIFIED
        if is_icon:
            self.present()
        else:
            if not self.has_toplevel_focus():
                self.present()
            else:
                self.iconify()
                #is_icon = False
        #self.set_skip_taskbar_hint(not is_icon)

    def onQuit(self, window, event):
        """ Post the quit message or iconify() if the event was sent explicitly
            (send_event is True) from windows manager or taskbar
        """
        import mods

        #print event, event.send_event#FIXME
        tray_active = 'TrayIcon' in prefs.get('mods', [])
        if event.type == gtk.gdk.DELETE and tray_active:
            self.onIconify()
            return True

        state = window.window.get_state()
        if state == 0:
            prefs.set('window-size', tuple(window.get_size()))
        prefs.set('window-maximize', bool(state == gtk.gdk.WINDOW_STATE_MAXIMIZED))
        #prefs.set('window-position', tuple(self.window.get_position()))
        window.hide()

        mods.postQuitMsg()
        return True
