# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Track:

    def __init__(self, path, tags=None):
        self.path = path
        self.tags = tags
        self.ppos = -1

    def __get(self, key, default):        
        try:    return self.tags[key]
        except: return default

    def __set(self, key, value):
        self.tags[key] = value

    def __splitExt(self, p, extsep='.'):
        dotIndex = p.rfind(extsep)
        if dotIndex != -1:
            return p[:dotIndex], p[dotIndex+1:].lower()
        else:
            return p, ''

    def __splitName(self):
        """ Return artist/title from a filename """
        filename, ext = self.__splitExt(self.getFileName())
        names = filename.replace('_', ' ').split(' - ')
        if len(names) == 2:
            return names
        else:
            return '~', self.getFileName()

    def getArtist(self):
        return self.__get('artist', self.__splitName()[0])

    def getAlbum(self):
        return self.__get('album', '~')

    def getImage(self):
        return self.__get('image', '')

    def getTitle(self):
        return self.__get('title', self.__splitName()[1])

    def getNumber(self):
        return self.__get('track-number', 0)

    def getLength(self):
        length = int(self.__get('length', 0))
        return length if length > 0 else 0

    def getBitrate(self):
        bitrate = self.__get('bitrate', 0)
        if bitrate <= 0: return '~'
        elif self.__get('channel-mode', '~') != 'stereo':
            return '~%d' % (bitrate /1000)
        else:
            return '%d' % (bitrate /1000)

    def getSampleRate(self):
        samplerate = self.__get('samplerate', 0)
        if samplerate <= 0: return '~'
        else: return '%.1f' % (samplerate /1000.0)

    def getType(self):
        return self.__splitExt(self.getFileName())[1]

    def getDirName(self):  return self.path[:self.path.rfind('/')]
    def getFileName(self): return self.path.split('/')[-1]
    #ef getFileSize(self): import os; return os.stat(self.path).st_size

    def getMPRISMetadata(self):
        """ Return a dictionary in an MPRIS-compatible format """
        data = {}

        data['artist']  = self.getArtist()
        data['title']   = self.getTitle()
        data['album']   = self.getAlbum()
        data['arturl']  = self.getImage()
        data['time']    = self.getLength()
        data['mtime']   = data['time'] * 1000
        data['year']    = 0
        data['genre']   = '~'
        data['rating']  = 0
        data['tracknumber']= self.ppos
        data['location']= self.path

        return data
