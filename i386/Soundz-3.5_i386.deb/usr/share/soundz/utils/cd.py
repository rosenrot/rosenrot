# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME
def loadDisc():
    """ Play tracks from a CD Audio """
    import gudev

    client = gudev.Client(['block'])
    device_name = None
    disc_label = None

    for device in client.query_by_subsystem('block'):
        if device.has_property('ID_CDROM_MEDIA_CD'):
            for key in device.get_property_keys():
                print "   property %s: %s" % (key, device.get_property(key))
            device_name = device.get_property('DEVNAME')
            break
    try:
        import DiscID
        discInfo = DiscID.disc_id(DiscID.open(device_name))
    except Exception, err:
        print str(err)
        return None

    #return getTracks(discInfo)
    #FIXME
    import mods
    mods.postMsg(mods.CMD_TRACKS_SET, {'tracks': getTracks(discInfo), 'playNow': True})

def getDiscInformation(discInfo):
    """ Return disc information from online CDDB, None if request fails """
    import CDDB

    try:
        (status, info) = CDDB.query(discInfo)
        if   status == 200: disc = info    # success
        elif status == 210: disc = info[0] # exact multiple matches
        elif status == 211: disc = info[0] # inexact multiple matches
        else: raise

        (status, info) = CDDB.read(disc['category'], disc['disc_id'])
        if status == 210: return info
        else: raise
    except:
        #import traceback
        #print traceback.format_exc()
        return None

def getTracks(discInfo):
    """ Update the tracklist """
    from utils.track import Track

    cddbInfo = getDiscInformation(discInfo)
    # set artist/album information
    try:
        dTitle = cddbInfo['DTITLE'].strip().decode('iso-8859-15', 'replace')
        artist, album = dTitle.split(' / ')  
    except:
        artist, album = '~', 'AudioCD'
    # set track information
    tracks = []
    for i in xrange(discInfo[1]):
        try:
            tTitle = cddbInfo['TTITLE%u' % i].strip().decode('iso-8859-15', 'replace')
            if ' / ' in tTitle: artist, title = tTitle.split(' / ') 
            else: title = tTitle
        except:
            title = str(i+1)

        track = Track('cdda://%d' % (i+1))
        track.tags = {'artist': artist, 'album': album, 'title': title}
        tracks.append(track)

    return tracks
