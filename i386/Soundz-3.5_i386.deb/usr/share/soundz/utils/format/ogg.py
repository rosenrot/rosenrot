# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def getTrack(filename):
    """ Return a Track created from an Ogg Vorbis file """
    from mutagen.oggvorbis import OggVorbis

    oggFile = OggVorbis(filename)

    length     = int(round(oggFile.info.length))
    bitrate    = int(oggFile.info.bitrate)
    samplerate = int(oggFile.info.sample_rate)

    try:    artist = str(oggFile['artist'][0])
    except: artist = None

    try:    album = str(oggFile['album'][0])
    except: album = None

    try:    title = str(oggFile['title'][0])
    except: title = None

    try:    number = str(oggFile['tracknumber'][0])
    except: number = None

    try:    date = str(oggFile['date'][0])
    except: date = None

    try:    genre = str(oggFile['genre'][0])
    except: genre = None

    return filename, length, bitrate, artist, album, title
