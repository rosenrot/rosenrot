# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
import gobject

import mods
from utils import prefs

MOD_INFO = (__name__, '', True, False)

(
ROW_PRESET_IS_SEPARATOR,
ROW_PRESET_NAME,
ROW_PRESET_VALUES,
) = range(3)

class Equalizer(mods.Module):

    eq     = None
    preset = prefs.get('eq-preset', 'Flat')
    _lvls  = prefs.get('eq-levels', [0,0,0,0,0,0,0,0,0,0])
    _scls  = []
    _timer = None

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:   self.onAppStarted,
            #mods.MSG_APP_QUIT:     self.onAppQuit,
                   }
        mods.Module.__init__(self, handlers)

    def onAppStarted(self):
        """ The application is started """
        self.playBin = prefs.gstBin
        self.playBin.add_equalizer()
        self.__setEqualizer(self._lvls)

        btnEq = prefs.getWidget('btn-eq')
        btnEq.connect('clicked', self.onShowEqualizer)

    def onAppQuit(self):
        """ The application is about to quit """
        pass

    def __getPresets(self):
        self._list = []
        self._list.append(('Acoustic',
            ( 4,  5,  4,  3,  2,  1,  0,  1,  2,  4)))
        self._list.append(('Dance',
            ( 6,  5,  4,  3,  1,  0, -3, -5, -5,  0)))
        self._list.append(('Flat',
            ( 0,  0,  0,  0,  0,  0,  0,  0,  0,  0)))
        self._list.append(('Live',
            (-4, -2,  0,  2,  3,  3,  3,  3,  2,  0)))
        self._list.append(('Metal',
            ( 3,  4,  5,  1, -2,  0,  1,  1, -1, -1)))
        self._list.append(('Pop',
            ( 3,  6,  3, -2, -4, -3,  0,  2,  3,  5)))
        self._list.append(('Reggae',
            ( 1,  1,  1,  0, -3,  0,  3,  4,  2,  1)))
        self._list.append(('Rock',
            ( 5,  4,  2, -2, -3, -3,  2,  4,  5,  5)))
        self._list.append(('Techno',
            ( 4,  4,  3,  2,  0, -4, -2,  0,  3,  4)))

    def __fadeLvls(self, item, preset, lvls):
        self.preset = preset
        prefs.set('eq-preset', self.preset)

        self._lvls = list(lvls)
        for i in xrange(10):
            self._scls[i].handler_block_by_func(self.onScaleChanged)
        if self._timer:
            gobject.source_remove(self._timer)
        self._timer = gobject.timeout_add(50, self.__moveScales)

    def __moveScales(self):
        done = True
        for i in xrange(10):
            curr   = self._scls[i].get_value()
            target = self._lvls[i]
            diff = target -curr

            if abs(diff) > 0.25:
                new = curr +(diff /5.0)
                done = False
            else:
                new = target
            self._scls[i].set_value(new)

        if done:
            gobject.source_remove(self._timer)
            self._timer = None

            for i in xrange(10):
                self._scls[i].queue_draw()
                self._scls[i].handler_unblock_by_func(self.onScaleChanged)

            self.__setEqualizer(self._lvls)
            prefs.set('eq-levels', self._lvls)
            return False
        return True

    def __setEqualizer(self, lvls):
        for i,v in enumerate(lvls):
            self.playBin.equalizer.set_property('band%s' % i, lvls[i])

    def onShowEqualizer(self, item):
        """ Show the Equalizer dialog """
        if not self.eq:
            builder = prefs.setGlade('glade-eq.xml')

            for i in xrange(10):
                self._scls.append(builder.get_object('vscale' +str(i)))
                self._scls[i].set_range(-12, 12)
                self._scls[i].set_value(self._lvls[i])
                self._scls[i].connect('button-press-event', self.onScalePress)
                self._scls[i].connect('button-release-event', self.onScaleRelease)
                self._scls[i].connect('value-changed', self.onScaleChanged, i)
            self.__getPresets()

            from gui.player import GtkDialog

            self.eq = GtkDialog(builder.get_object('vbox1'), -1, -1)
            self.eq.set_decorated(False)
            self.eq.set_title('')

            btn = builder.get_object('btn-menu')
            btn.connect('button-press-event', self.onMenuPopup)
            btn = builder.get_object('btn-close')
            btn.connect('button-press-event',
                lambda w,e: self.eq.emit('delete-event', None))

        self.eq.set_visible(not self.eq.get_visible())

    def onMenuPopup(self, widget, event):
        """ Emitted on menu button """
        menu = gtk.Menu()
        for (n,v) in self._list:
            item = gtk.CheckMenuItem(n)
            item.set_active(self.preset == n)
            item.connect('activate', self.__fadeLvls, n, v)
            menu.add(item)
        menu.show_all()
        menu.popup(None, None, None, 0, event.get_time())

    def onScalePress(self, scale, event):
        """ Emitted on button press """
        if event.button == 1:
            event.button = 2
            scale.emit('button-press-event', event)

    def onScaleRelease(self, scale, event):
        """ Emitted on button release """
        if event.button == 1:
            event.button = 2
            scale.emit('button-release-event', event)

    def onScaleChanged(self, scale, idx):
        """ Emitted after the button release """
        if self.preset:
            self.preset = None
            prefs.set('eq-preset', None)

        self._lvls[idx] = scale.get_value()
        self.__setEqualizer(self._lvls)
        prefs.set('eq-levels', self._lvls)
