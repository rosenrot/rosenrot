# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
import os.path

from gettext import gettext as _
from pango import ELLIPSIZE_END

import gui, mods, utils
from gui import listDir, findAttr, htmlEscape
from gui.ext import ListView
from utils import prefs

MOD_INFO = (__name__, '', True, False)

(
    ROW_PIX,
    ROW_TYPE,
    ROW_NAME,
    ROW_PATH
) = range(4)

(
    TYPE_DIR,
    TYPE_FILE,
    TYPE_NONE
) = range(3)

NONE  = prefs.pixEmpty()
ERROR = prefs.pixIcon(gtk.STOCK_CANCEL)
PLAY  = prefs.pixIcon(gtk.STOCK_MEDIA_PLAY)
PAUSE = prefs.pixIcon(gtk.STOCK_MEDIA_PAUSE)
DIR   = prefs.pixTheme('mime-dir')
AUDIO = prefs.pixTheme('mime-audio')
VIDEO = prefs.pixTheme('mime-video')

class Explorer(mods.Module):

    dirRoot = None
    expList = None
    __tabs  = []

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:     self.onAppStarted,
            mods.MSG_APP_QUIT:        self.onAppQuit,
                   }
        mods.Module.__init__(self, handlers)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onAppStarted(self):
        self.__getListView()
        self.scrollwin = prefs.getWidget('scrolled2')
        self.scrollwin.add(self.expList)
        #self.insert(self.dirRoot)

        self.entry = prefs.getWidget('entry1')#FIXME
        #self.entry.connect('activate', self.onEntryActivate)
        #self.entry.connect('icon-press', self.onEntryIconPressed)
        #self.entry.connect('focus-out-event', lambda w,e: w.set_visible(
        #    w.get_icon_stock(1) == gtk.STOCK_CLEAR))

        self.notebook = prefs.getWidget('notebook2')
        self.notebook.connect('switch-page', lambda w,pw,pn:
            self.__revert(self.entry) if pn != 1 else None)

        self.tab = prefs.getWidget('btn-exp')
        self.tab.connect('clicked', self.__tabClicked, prefs.dirUsr)
        self.tabs = prefs.getWidget('hbox-tabs')
        self._tabswidth = self.tabs.get_allocation().width

        self.insert(self.dirRoot)

    def __tabClicked(self, tab, dir):
        self.insert(dir)
        self.notebook.set_current_page(1)

    def onAppQuit(self):
        if self.dirRoot != None:
            prefs.set('explorer-root-dir', self.dirRoot)

    def __getListView(self):
        from gobject import TYPE_STRING, TYPE_INT, TYPE_PYOBJECT

        pixRdr = gtk.CellRendererPixbuf()
        txtRdr = gtk.CellRendererText()
        txtRdr.set_property('width-chars', 64)
        txtRdr.set_property('ellipsize', 'end')

        columns = (
            ('#', [(pixRdr, gtk.gdk.Pixbuf), (txtRdr, TYPE_INT)], (ROW_TYPE,),
            False, True),
            (_('Name'), [(txtRdr, TYPE_STRING)], (ROW_NAME,),
            True, True),
            (None, [(None, TYPE_PYOBJECT)], (ROW_PATH,),
            False, False)
            )

        self.expList = ListView(columns, False, False, False)

        self.expList.get_column(0).set_max_width(20)
        self.expList.get_column(1).set_max_width(100)

        self.expList.connect('extlistview-button-pressed', self.onButtonPressed)
        self.expList.connect('key-press-event', self.onKeyPressed)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def __list(self, dirRoot):
        dirs = []
        files = []
        playlists = []

        for (file, path) in listDir(dirRoot, False):
            if os.path.isdir(path):
                dirs.append( (DIR, TYPE_DIR, file, path) )
            elif os.path.isfile(path):
                if utils.isAudio(file):
                    files.append( (AUDIO, TYPE_FILE, file, path) )
                elif utils.isVideo(file):
                    files.append( (VIDEO, TYPE_FILE, file, path) )
                elif utils.isPlaylist(file):
                    playlists.append( (PLAY, TYPE_FILE, file, path) )

        def sort_name(row):
            return row[ROW_NAME].lower()
        def sort_ext(row):
            return row[ROW_NAME][row[ROW_NAME].rfind('.')+1:].lower()

        dirs.sort(key=sort_name)
        files.sort(key=sort_name)#; files.sort(key=sort_ext)
        playlists.sort(key=sort_name)

        return (dirs, files, playlists)

    def insert(self, dirRoot=None):
        if dirRoot == None:
            dirRoot = prefs.get('explorer-root-dir', prefs.dirUsr)   
        if os.access(dirRoot, os.R_OK | os.X_OK):# and dirRoot != self.dirRoot:
            self.dirAbove = dirRoot[:dirRoot.rfind('/')]#self.dirRoot
            self.dirRoot = dirRoot

            dirs, playlists, files = self.__list(dirRoot)

            if dirRoot != prefs.dirUsr:
                dirs.insert(0, (DIR, TYPE_DIR, '...',
                    dirRoot[:dirRoot.rfind('/')]))
                dirName = dirRoot[dirRoot.rfind('/')+1:]             
            else:
                dirName = _('Home')

            self.rows = dirs +playlists +files
            self.expList.clear()
            self.expList.insertRows(self.rows)
            #self.expList.setColumnLabel(1, htmlEscape(dirName))

            for tab in self.__tabs: tab.destroy()
            self.__tabs = []

            for i in dirRoot.split('/'):
                if i not in prefs.dirUsr:
                    tab = gtk.Button(i, None, False)
                    label = tab.get_children()[0]
                    label.set_max_width_chars(16)
                    label.set_ellipsize(ELLIPSIZE_END)
                    #tab.set_relief(gtk.RELIEF_NONE)
                    tab.unset_flags(gtk.CAN_FOCUS)
                    tab.connect('clicked',
                        self.__tabClicked, dirRoot[:dirRoot.rfind(i)+len(i)] )
                    tab.show()

                    self.__tabs.append(tab)
                    if len(self.__tabs) > 3:
                        self.__tabs[0].destroy()
                        self.__tabs.pop(0)

                    self.tabs.pack_start(tab, expand=False, fill=True, padding=0)
                    self.tabs.reorder_child(tab, len(self.__tabs) +1)
            #self.tabs.show_all()

    def crop(self):
        self.expList.cropSelectedRows()
        self.expList.unselectAll()

    def revert(self):
        self.expList.clear()
        self.expList.insertRows(self.rows)

    def play(self, replace):
        files = [row[ROW_PATH] for row in self.expList.getSelectedRows()]
        recursive = prefs.get('explorer-sub-dirs', True)

        tracks = utils.getTracks(files, recursive)
        if tracks:
            if replace: mods.postMsg(
                mods.CMD_TRACKS_SET, {'tracks': tracks})
            else: mods.postMsg(
                mods.CMD_TRACKS_ADD, {'tracks': tracks, 'playNow': False})
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onButtonPressed(self, listview, event, path):
        """ Emitted at click of a list item """
        if event.button == 1 and event.type == gtk.gdk._2BUTTON_PRESS and path:
            row = self.expList.getRow(path[0])

            if row[ROW_TYPE] == TYPE_DIR:
                self.insert(row[ROW_PATH])
            elif row[ROW_TYPE] == TYPE_FILE:
                mods.postMsg(mods.CMD_TRACKS_SET, {
                    'tracks': utils.getTracks([row[ROW_PATH],]),
                    'playNow': True})

        elif event.button == 3:
            self.onPopupMenu(listview, path, event.button, event.time)

    def onEntryActivate(self, entry):
        """ Emitted on new search action """
        if self.notebook.get_current_page() != 1:
            return
        text = entry.get_text().lower()
        if not text:
            self.__revert(entry)
            return
        self.expList.unselectAll()
        for n,r in enumerate(self.rows):
            if findAttr(text, r[ROW_NAME].lower()):
                self.expList.selectRow(n)
        if self.expList.getSelectedRowsCount() != 0:
            self.crop()
            entry.set_icon_from_stock(1, gtk.STOCK_CLEAR)
        entry.set_text('')

    def onEntryIconPressed(self, entry, icon, event):
        """ Emitted when an icon of the entry is pressed """
        if self.notebook.get_current_page() != 1:
            return
        elif icon == gtk.ENTRY_ICON_SECONDARY:
            self.__revert(entry)

    def __revert(self, entry):
        if entry.get_icon_stock(1) == gtk.STOCK_CLEAR:
            self.revert()
            entry.set_icon_from_stock(1, None)            
        entry.hide()

    def onPopupMenu(self, listview, path, button, time):
        """ Emitted at right-click """
        menu = gtk.Menu()

        play = gtk.ImageMenuItem(gtk.STOCK_MEDIA_PLAY)
        play.set_sensitive(path != None)
        play.connect('activate', lambda w: self.play(True))
        menu.append(play)
        add = gtk.ImageMenuItem(gtk.STOCK_ADD)
        add.set_sensitive(path != None)
        add.connect('activate', lambda w: self.play(False))
        menu.append(add)
        sub = gtk.CheckMenuItem(_('Recursive'))
        sub.set_active(prefs.get('explorer-sub-dirs', True))
        sub.connect('activate', lambda w:
            prefs.set('explorer-sub-dirs', w.get_active()))
        menu.append(sub)

        menu.append(gtk.SeparatorMenuItem())
        home = gtk.ImageMenuItem(gtk.STOCK_HOME)
        home.set_sensitive(self.dirRoot != prefs.dirUsr)
        home.connect('activate', lambda w: self.insert(prefs.dirUsr))
        menu.append(home)
        back = gtk.ImageMenuItem(gtk.STOCK_GO_BACK)
        back.set_sensitive(len(self.dirAbove) >= len(prefs.dirUsr))
        back.connect('activate', lambda w: self.insert(self.dirAbove))
        menu.append(back)

        menu.append(gtk.SeparatorMenuItem())
        close = gtk.ImageMenuItem(gtk.STOCK_CLOSE)
        close.connect('activate', lambda w: self.notebook.set_current_page(0))
        menu.append(close)

        menu.show_all()
        menu.popup(None, None, None, button, time)

    def onKeyPressed(self, list, event):
        """ Emitted at key press """
        key = gtk.gdk.keyval_name(event.keyval)
        if len(key) == 1 and key.isalnum():
            self.entry.show()
            self.entry.set_text(key)
            self.entry.grab_focus()
            self.entry.do_move_cursor(self.entry, 1, 1, False)
