# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Logger:

    colors = {
        'reset'     : '\x1b[0m',
        'bold'      : '\x1b[01m',
        'teal'      : '\x1b[36;06m',
        'turquoise' : '\x1b[36;01m',
        'fucsia'    : '\x1b[35;01m',
        'purple'    : '\x1b[35;06m',
        'bluebold'  : '\x1b[34;01m',
        'blue'      : '\x1b[34;06m',
        'yellowbold': '\x1b[33;01m',
        'yellow'    : '\x1b[33;06m',
        'greenbold' : '\x1b[32;01m',
        'green'     : '\x1b[32;06m',
        'redbold'   : '\x1b[31;01m',
        'red'       : '\x1b[31;06m',
        }

    def __init__(self, debug=False):
        #global self.__log
        self.__log = debug

    def lprint(self, msg, f, cl):
        if self.__log:
            print '%s[%s]\x1b[0m %s' % (self.colors[cl], f, msg)
        else:
            print msg

    def debug(self, msg):
        if self.__log:
            self.lprint(msg, 'DEBUG', 'blue')

    def error(self, msg=''):
        if self.__log:
            import traceback
            msg = traceback.format_exc()
            self.lprint(msg, 'ERROR', 'red')
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Server(object):

    def __init__(self, target, callback, *args):
        super(Server, self).__init__()
        self.target = target
        self.callback = callback
        self.args = args

    def __call__(self, *args):
        if self.callback != None:
            args += self.args
            self.callback(*args)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gobject
gobject.threads_init()
import thread

# from mods import configs
from mods import cfg
configs = cfg.SafeParser()
configs.load()

# from mods import log
log = Logger(configs.getboolean('Coverz', 'debug'))

from players import Track

COVER, PLAYER, STATE, TIME, TRACK = range(5)
STARTED, PLAYING, PAUSED, STOPPED, CLOSED = range(5)

class Thread(object):

    cover   = None
    player  = None
    state   = CLOSED
    track   = Track()
    time    = 0

    _players = {}
    _plugins = {}
    _servers = [], [], [], [], []
    _timeout = 0
    _timer   = 0
    _track   = track

    def __init__(self):
        super(Thread, self).__init__()

        log.debug('Starting D-Bus...')
        self.init_dbus()

        log.debug('Checking players...')
        if configs.getboolean('Coverz', 'autoplug'):
            self._add_players()
            self._timeout = gobject.timeout_add(10000, self._check_players)
        self.init_player(configs.get('Coverz', 'player'))

        log.debug('Loading plugins...')
        self.covers = configs.get('Coverz', 'covers')
        self.lyrics = configs.get('Coverz', 'lyrics')
        for p in (self.covers, self.lyrics):
            self.init_plugin(p)

        self.attach(STATE, self.update_state)
        self.attach(TRACK, self.update_track)

        self.window = Window(self)

    def init_dbus(self):
        import dbus
        from dbus.mainloop.glib import DBusGMainLoop

        dbus.set_default_main_loop(DBusGMainLoop(set_as_default=True))
        dbus_name = 'org.freedesktop.DBus'
        dbus_path = '/org/freedesktop/DBus'

        self.dbus_obj = dbus.SessionBus().get_object(dbus_name, dbus_path)

    def _add_players(self):
        for p in cfg.listdir('players'):
            try:
                self._players[p] = __import__('players.' +p,
                    fromlist=['players']).__dict__[p].DBUS_NAME
            except:
                log.error()

    def _check_players(self):
        for p, n in self._players.items():
            if n in self.dbus_obj.ListNames() and self.player.DBUS_NAME != n:
                self.player.close()
                self.init_player(p)
                break
        return True#!callback(*args) not be True

    def init_player(self, p):
        try:
            self.player = __import__('players.' +p,
                fromlist=['players']).__dict__[p](self)
            self.update(PLAYER, self.player)
            gobject.idle_add(self.update_player)
        except:
            log.error()

    def init_plugin(self, p):
        try:
            self._plugins[p] = __import__('plugins.' +p,
                fromlist=['plugins']).__dict__[p](self)
        except:
            log.error()

    def init_timer(self):
        if self._timer:
            gobject.source_remove(self._timer)
            self._timer = None
            if self.state > PAUSED:
                self.time = 0
                self.update(TIME, self.time)
            log.debug('Timer stopped')

        if self.state < PAUSED and 'time' in self.player.capabilities and \
            len(self._servers[TIME]) > 0:
            self._timer = gobject.timeout_add(1000, self.update_time)
            self.update_time()
            log.debug('Timer started')

    def init_window(self):
        from mods.win import Window

        #self.window = Window(self)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def attach(self, target, callback, *args):
        ob = Server(target, callback, *args)
        self._servers[target].append(ob)

        if target == TIME:
            self.init_timer()
        return ob

    def detach(self, server):
        self._servers[server.target].remove(server)
        if server.target == TIME:
            self.init_timer()

    def update(self, target, *args):
        for callback in self._servers[target]:
            #try: print str([callback, target, args ])
            #except: pass
            try: callback(*args)
            except: pass #Exception, err: print err
        return False

    def update_lyric(self):
        thread.start_new_thread(self._plugins[self.lyrics].get, (self.track,))

    def update_player(self):
        try: state = self.player.get_state()
        except: state = CLOSED
        if state in (PLAYING, PAUSED):
            track = self.player.get_track()
        else:
            track = self._track

        self.update(TRACK, track)
        self.update(STATE, state)

    def update_state(self, state):      
        if self.state != state:
            self.state = state
            if state == STARTED:
                self.update_player()                
            elif state >= STOPPED:
                self.update(TRACK, self._track)

            self.init_timer()

    def update_time(self):
        time = self.player.get_position()
        if self.time != time:
            self.time = time
            self.update(TIME, time)
        return True

    def update_track(self, track):
        self.track = track
        if track.cover:            
            self.update(COVER, track.cover)
        elif len(track.artist) > 1:
            thread.start_new_thread(self._plugins[self.covers].get, (track,))
        else:
            self.update(COVER, self.cover)
        return False

#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gtk
gtk.gdk.threads_init()

#from mods import cfg
#from mods import configs

class Window(gtk.Window):

    _pt = False
    _px = 0
    _py = 0

    _ontop = False
    _stick = False
    _menu  = None

    def __init__(self, thread):
        super(Window, self).__init__()
        self.THREAD = thread

        self.set_app_paintable(True)
        #FIXME colormap issue on scrolling
        self.set_colormap(self.get_screen().get_rgba_colormap())
        self.set_decorated(False)
        #FIXME dock hint has issue with some wm, not tested on unity
        #self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_NOTIFICATION)#_DOCK)
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_UTILITY)
        self.set_title('Coverz')
        self.set_icon_from_file(cfg.ABS_PATH +'/skins/coverz.png')

        try: x, y = configs.get('Coverz', 'position').split(',')
        except: x, y = 10, 10
        self.move(int(x), int(y))

        self.set_property('accept-focus', False)#???
        #self.set_ontop(False)
        #self.set_stick(True)
        self.set_ontop(configs.getboolean('Coverz', 'ontop'))
        self.set_stick(configs.getboolean('Coverz', 'stick'))

        #!add transparent background
        self.connect('expose-event', self.expose_event)

        self.add_events(gtk.gdk.BUTTON_PRESS_MASK)
        self.add_events(gtk.gdk.BUTTON_RELEASE_MASK)
        self.add_events(gtk.gdk.POINTER_MOTION_MASK)
        #self.add_events(gtk.gdk.ENTER_NOTIFY_MASK)

        self.connect('button-press-event', self.show_menu)
        self.connect('button-press-event', self.button_press)
        self.connect('button-release-event', self.button_release)
        self.connect('motion-notify-event', self.motion_notify)
        #self.connect('window-state-event', self.state_event)
        #self.connect('enter-notify-event', self.enter_notify)
        #self.connect('leave-notify-event', self.leave_notify)
        #if configs.getboolean('Coverz', 'trayicon'):
        #    self._status_icon = gtk.status_icon_new_from_file(
        #        cfg.ABS_PATH +'/tray.png')
        #    self._status_icon.connect('button-press-event', self.show_menu)

        log.debug('Loading skin...')
        self.init_skin()

    def set_ontop(self, ontop):
        self.set_keep_above(ontop)
        self.set_keep_below(not ontop)
        self._ontop = ontop

    def set_stick(self, stick):
        self.stick() if stick else self.unstick()
        self.set_skip_taskbar_hint(stick)
        self.set_skip_pager_hint(stick)           
        self._stick = stick

    def button_press(self, widget, event):
        if event.button == 1 and not self._stick:
            self._pt = True
            self._px, self._py = self.get_position()
            self._px = event.x_root - self._px
            self._py = event.y_root - self._py
        return False

    def button_release(self, widget, event):
        if event.button == 1:
            self._pt = False
        return False

    def motion_notify(self, widget, event):
        if self._pt:
            self.move(int(event.x_root-self._px), int(event.y_root-self._py))
        return False

    def enter_notify(self, widget, event):
        print event#FIXME
        return False

    def leave_notify(self, widget, event):
        print event#FIXME
        return False

    def expose_event(self, widget, event):
        cr = self.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        cr.set_operator(cairo.OPERATOR_CLEAR)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        return False

    def state_event(self, widget, event):
        print event#FIXME
        return False

    def show_menu(self, widget, event):
        if event.button == 2:
            self.THREAD.update_lyric()
        if event.button != 3:
            return
        if self._menu == None:
            self._menu = gtk.Menu()

            ontop = gtk.CheckMenuItem('Always on top')
            self._menu.append(ontop)
            stick = gtk.CheckMenuItem('Stick to desktop')
            self._menu.append(stick)

            self._menu.__stick = stick
            self._menu.__ontop = ontop

            ontop.connect ('activate',
                lambda w: self.set_ontop(w.active))
            stick.connect ('activate',
                lambda w: self.set_stick(w.active))

            self._menu.append(gtk.SeparatorMenuItem())
            install = gtk.ImageMenuItem('Install skin...')
            install.connect ('activate',
                lambda w: self.install_skin('Install skin...'))
            install.set_image(gtk.image_new_from_stock(
                gtk.STOCK_NEW, gtk.ICON_SIZE_MENU))
            self._menu.append(install)

            edit = gtk.ImageMenuItem('Edit config')
            edit.set_image(gtk.image_new_from_stock(
                gtk.STOCK_EDIT, gtk.ICON_SIZE_MENU))
            edit.connect ('activate',
                lambda w: cfg.edit())
            self._menu.append(edit)

            reinit = gtk.ImageMenuItem('Reload')
            reinit.set_image(gtk.image_new_from_stock(
                gtk.STOCK_REFRESH, gtk.ICON_SIZE_MENU))
            reinit.connect ('activate',
                lambda w: self.quit(True))
            self._menu.append(reinit)

            self._menu.append(gtk.SeparatorMenuItem())
            quit = gtk.ImageMenuItem(gtk.STOCK_QUIT)
            quit.connect ('activate',
                lambda w: self.quit(False))
            self._menu.append(quit)
            self._menu.show_all()

        self._menu.__ontop.set_active(self._ontop)
        self._menu.__stick.set_active(self._stick)

        self._menu.popup(None, None, None, event.button, event.time)

    def install_skin(self, title='', parent=None, buttons=(
        gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK)):
        dlg = gtk.FileChooserDialog(title, parent,
            gtk.FILE_CHOOSER_ACTION_OPEN, buttons)
        dlg.set_current_folder(cfg.HOME_PATH)
        dlg.set_select_multiple(False)

        f = gtk.FileFilter()
        f.set_name('7z | zip')
        for p in ('*.7z','*.zip'):
            f.add_pattern(p)
        dlg.add_filter(f)

        _file = None
        if dlg.run() == gtk.RESPONSE_OK:
            _file = dlg.get_filename()
            if _file:
                cfg.unzip(_file)
        dlg.destroy()
        #return _file

    def init_skin(self):
        from mods.skin import Skin

        skin = Skin(self.THREAD)
        try:
            skin.get_skin_xml(cfg.USR_PATH)
        except:
            log.error()
            #!load default skin
            skin.get_skin_xml(cfg.ABS_PATH +'/skins')

        self.fixed = gtk.Fixed()
        for w,n in skin.widgets:
            self.fixed.put(w, w.get_x(), w.get_y())

        self.add(self.fixed)
        self.set_size_request(*skin.size)
        self.show_all()

        gtk.main()

    def quit(self, restart=False):
        configs.set('Coverz', 'position', '%d,%d' % self.window.get_position())
        configs.save()

        gtk.main_quit()

        if restart:
            import subprocess
            subprocess.Popen(['coverz'])
