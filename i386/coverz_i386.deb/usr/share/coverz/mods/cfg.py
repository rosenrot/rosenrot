# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os

from ConfigParser import SafeConfigParser

ABS_PATH    = os.path.join(os.path.dirname(__file__), '..')
HOME_PATH   = os.path.expanduser('~')
USR_PATH    = HOME_PATH +'/.coverz'
TMP_PATH    = USR_PATH +'/.tmp'

if not os.path.exists(USR_PATH):
    os.mkdir(USR_PATH)
if not os.path.exists(TMP_PATH):
    os.mkdir(TMP_PATH)

CONFIG = USR_PATH +'/.cfg'

class SafeParser(SafeConfigParser):

    _mtime = 0

    def __init__(self):
        SafeConfigParser.__init__(self)

        self.load_default()
        self.save()

    def load_default(self):
        self.add_section('Coverz')
        self.set('Coverz', 'autoplug',  '1')
        self.set('Coverz', 'debug',     '0')
        self.set('Coverz', 'player',    'Soundz')
        self.set('Coverz', 'covers',    'Lastfm')
        self.set('Coverz', 'lyrics',    'Musixmatch')
        self.set('Coverz', 'ontop',     '0')
        self.set('Coverz', 'stick',     '1')
        self.set('Coverz', 'position',  '10,10')

    def load(self):
        try: self._mtime = os.path.getmtime(CONFIG)
        except: self._mtime = 0
        if self._mtime != 0:
            self.read(CONFIG)

    def save(self):
        try: _mtime = os.path.getmtime(CONFIG)
        except: _mtime = 0
        if _mtime == self._mtime:
            with open(CONFIG, 'w') as f:
                self.write(f)

def edit():
    import subprocess
    subprocess.Popen(['xdg-open', CONFIG])

def listdir(dir):
    return sorted([f[:-3] for f in os.listdir(os.path.join(ABS_PATH, dir)) \
        if not f.startswith('_') and f.endswith('.py')])

def unzip(file):
    import subprocess   
    try:
        for f in os.listdir(USR_PATH):
            if not f[0] == '.':
                os.remove(os.path.join(USR_PATH, f))
        unzip = subprocess.Popen(['7z','e',file,'-o'+USR_PATH,'-y'])#,
        #    stderr=subprocess.PIPE)
        #while unzip.poll() != None:
        #    print unzip.stderr.read()
        #subprocess.Popen(['xdg-open', USR_PATH])
    except:
        pass
