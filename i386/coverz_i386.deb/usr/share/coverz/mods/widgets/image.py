# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gobject
from gtk import gdk

from mods.widgets import Widget

class Image(Widget):

    _path = None
    _surface = None
    _clip = None
    _mask = None
    _opacity = 1.0
    _radius = 0
    _radians = 0

    def __init__(self, size):
        super(Image, self).__init__(size)

        self._init_size = size.width, size.height
        self._safe_size = int(size.width *1.4), int(size.height *1.4)

    def get_width(self):
        if self._radians:
            return self._safe_size[0]
        else:
            return self._init_size[0]

    def get_height(self):
        if self._radians:
            return self._safe_size[1]
        elif self._reflect:
            return int(self._size.height +self._reflect.gap +self._reflect.height)
        else:
            return self._init_size[1]

    def set_image(self, path):
        if self._path != path:
            self._path = path
            if path:
                self.set_size_request(self.get_width(), self.get_height())
                if self._radians:
                    (w, h), (sw, sh) = self._init_size, self._safe_size
                    self._rotate_surface(w, h, sw, sh)
                else:
                    self._draw_surface()
            self.queue_draw()

    def set_clip(self, rect):
        self._clip = rect

    def set_mask(self, path):
        self._mask = path

    def set_opacity(self, opacity):
        if opacity >= 0.0 and opacity <= 1.0:
            self._opacity = opacity
        else:
            raise ValueError

    def set_rotate(self, rotate):
        self._radians = rotate

        self._size.set_width(self.get_width())
        self._size.set_height(self.get_height())

    def set_round(self, radius):
        if radius > 1 and radius < (self._size.width /2 +1) and \
        radius < (self._size.height /2 +1):
            self._radius = radius
        else:
            raise ValueError

    def _draw_surface(self):
        self._surface = cairo.ImageSurface(cairo.FORMAT_ARGB32,
            self._size.width, self._size.height)
        cr = gdk.CairoContext(cairo.Context(self._surface))
        cr.save()

        pixbuf = gdk.pixbuf_new_from_file_at_scale(self._path,
            self._size.width, self._size.height, False)
        cr.set_source_pixbuf(pixbuf, 0, 0)

        if self._radius:
            w, h = self._size.width, self._size.height
            self._clip_round(cr, w, h, self._radius)

        cr.paint_with_alpha(self._opacity)

        if self._mask:
            maskbuf = gdk.pixbuf_new_from_file_at_scale(self._mask,
                self._size.width, self._size.height, False)
            cr.set_operator(cairo.OPERATOR_DEST_OUT)
            cr.set_source_pixbuf(maskbuf, 0, 0)
            cr.paint()
        cr.restore()

        if self._clip:
            rx, ry, rw, rh = self._clip
            cr.set_operator(cairo.OPERATOR_DEST_OUT)
            cr.rectangle(int(rx), int(ry), int(rw), int(rh))
            cr.clip()
            cr.paint()

    def _rotate_surface(self, w, h, sw, sh):
        self._surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, sw, sh)
        cr = gdk.CairoContext(cairo.Context(self._surface))
        cr.save()

        cr.translate((sw -w) /2, (sh -h) /2)
        cr.translate(w *0.5, h *0.5)
        cr.rotate(self._radians)
        cr.translate(-w *0.5, -h *0.5)

        pixbuf = gdk.pixbuf_new_from_file_at_scale(self._path, w, h, False)
        cr.set_source_pixbuf(pixbuf, 0, 0)

        if self._radius:
            self._clip_round(cr, w, h, self._radius)

        cr.paint_with_alpha(self._opacity)

        if self._mask:
            maskbuf = gdk.pixbuf_new_from_file_at_scale(self._mask, w, h, False)
            cr.set_operator(cairo.OPERATOR_DEST_OUT)
            cr.set_source_pixbuf(maskbuf, 0, 0)
            cr.paint()
        cr.restore()

        if self._clip:
            rx, ry, rw, rh = self._clip
            cr.set_operator(cairo.OPERATOR_DEST_OUT)
            cr.rectangle(int(rx), int(ry), int(rw), int(rh))
            cr.clip()
            cr.paint()

    def _clip_round(self, cr, w, h, r):
        cr.move_to ( r, 0 )
        cr.line_to ( w-r, 0 )
        cr.curve_to( w-r, 0, w, 0, w, r )
        cr.line_to ( w, h-r )
        cr.curve_to( w, h-r, w, h, w-r, h )
        cr.line_to ( r, h )
        cr.curve_to( r, h, 0, h, 0, h-r )
        cr.line_to ( 0, r )
        cr.curve_to( 0, r, 0, 0, r, 0)
        cr.clip()

    def do_expose_event(self, event):
        if self._path == None:
            return True

        cr = event.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        cr.translate(self._size.x, self._size.y)
        cr.set_source_surface(self._surface, self._size.x, self._size.y)
        cr.set_source_surface(self._surface, 0, 0)
        cr.paint()

        if self._reflect:
            cr.translate(0, 2 *self._size.height +self._reflect.gap)
            cr.scale(1, -1)
            linear = cairo.LinearGradient(0, self._size.height,
                0, self._size.height -self._reflect.height)
            linear.add_color_stop_rgba(0, 0, 0, 0,
                self._reflect.alpha *self._opacity)
            linear.add_color_stop_rgba(1, 0, 0, 0, 0)
            cr.set_source_surface(self._surface, 0, 0)
            cr.mask(linear)

        return True

gobject.type_register(Image)
