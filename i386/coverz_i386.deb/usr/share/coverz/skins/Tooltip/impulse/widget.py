# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#!v0.3~mickyz(c)2013

import gobject
import os
os.chdir(os.path.dirname(__file__))

import sys
import impulse
sys.modules[__name__].impulse = impulse

try:
    import ctypes
    libc = ctypes.CDLL('libc.so.6')
    libc.prctl(15, os.path.split(sys.argv[0])[1], 0, 0, 0)
except Exception, err:
    print err

import cairo
from gtk import gdk

from mods.widgets import Widget

class Skin(Widget):

    _timer  = None
    _timerms = 150

    def __init__(self, attrs):
        super(Skin, self).__init__(attrs['size'])
      
        self.rect_size = attrs['size']
        self.set_size_request(self.get_width(), self.get_height())
        self.queue_draw()

        self._skin = __import__(attrs['skin'])
        #self._skin = __import__('skin.' +name, fromlist=['skin'])
        for k, v in attrs.items():          
            if hasattr(self._skin, k):
                setattr(self._skin, k, v)

        impulse.setSourceIndex(attrs['src'])

    def do_expose_event(self, event):
        cr = event.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        cr.translate(self._size.x, self._size.y)
        cr.set_operator(cairo.OPERATOR_OVER)

        self.on_draw(cr)

    def on_draw(self, cr):
        fft = hasattr(self._skin, 'fft') and self._skin.fft
        audio_sample_array = impulse.getSnapshot(fft)

        self._skin.on_draw(audio_sample_array, cr, self)

    def change_state(self, state):
        if self._timer:
            gobject.remove(self._timer)
            self._timer = None
        if state == 1:
            self._timer = gobject.timeout_add(self._timerms, self.update)

    def update(self):
        x, y, w, h = self.rect_size
        rect = gdk.Rectangle(x, y, w, h)
        if self.window:
            self.window.invalidate_rect(rect, True)
            self.window.process_updates(True)
        return True #!keep running this event

gobject.type_register(Skin)
