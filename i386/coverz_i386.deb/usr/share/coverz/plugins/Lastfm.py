# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

from mods import log
from plugins import CoverPlugin

class Lastfm(CoverPlugin):

    api_url = 'http://ws.audioscrobbler.com/2.0/?method='
    api_key = '03847dec370bfcfe516815d7ff8a3da2'
    #pi_key = 'fd8dd98d26bb3f288f3e626502f9add6'

    def get(self, track):
        """ Download the covers from Last.fm """
        path = self.find(track)
        if path == None:
            try:
                data = self.get_cover(track)
                self.save(track, data)
            except:
                path = None
                log.error()
        self.update(path)  

    def get_cover(self, track):
        artist, album = self.encode(track.artist), self.encode(track.album)
        if len(track.album) > 1:
            pix_url = self.get_album_cover(artist, album)
        elif len(track.artist) > 1:
            pix_url = self.get_artist_cover(artist)
        return self.read(pix_url)

    def get_album_cover(self, artist, album):
        query = 'album.getinfo&artist=%s&album=%s&api_key=' % (artist, album)
        data = self.read(self.api_url +query +self.api_key)
        sst = '<image size="large">'
        start = data.find(sst)
        end = data.find('</image>', start)
        return data[start+len(sst):end]

    def get_artist_cover(self, artist):
        query = 'artist.getimages&artist=%s&api_key=' % artist
        data = self.read(self.api_url +query +self.api_key)
        sst = '<size name="largesquare" width="126" height="126">'
        start = data.find(sst)
        end = data.find('</size>', start)
        return data[start+len(sst):end]
