# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import dbus
import gobject

from mods import log

COVER, PLAYER, STATE, TIME, TRACK = range(5)
STARTED, PLAYING, PAUSED, STOPPED, CLOSED = range(5)

class Player(object):
    """ Player basic functions, extend it for specific functions """

    __doc__     = 'Generic API for music players'

    DBUS_NAME   = None
    DBUS_OBJECT = None

    capabilities = ()

    _player = None
    _signal = None
    _signals = []

    def __init__(self, thread):
        super(Player, self).__init__()
        self.THREAD = thread

        if self.DBUS_NAME:
            self._signal = dbus.SessionBus().add_signal_receiver(
                self._dbus_handler, 'NameOwnerChanged',
                'org.freedesktop.DBus', None,
                '/org/freedesktop/DBus')

        if self.is_active(self.DBUS_NAME):
            log.debug('Connecting... <%s>' % self.DBUS_NAME)
            self.connect()

    def _dbus_handler(self, name, a=None, b=None):
        if name == self.DBUS_NAME:
            if self.is_active(name):
                log.debug('Connecting... <%s>' % self.DBUS_NAME)
                if self.connect():
                    self.THREAD.update(STATE, STARTED)
            else:
                log.debug('Disconnecting... <%s>' % self.DBUS_NAME)
                self.disconnect()
                self.THREAD.update(STATE, CLOSED)

    def is_active(self, name):
        return name in self.THREAD.dbus_obj.ListNames()

    def close(self):
        self.disconnect()
        if self._signal:
            self._signal.remove()
            self._signal = None
        self.THREAD.update(STATE, CLOSED)

    def connect(self):
        raise NotImplementedError

    def disconnect(self):
        raise NotImplementedError

    def get_state(self):
        raise NotImplementedError

    def get_track(self):
        raise NotImplementedError

    def previous(self):
        pass

    def play(self):
        pass

    def next(self):
        pass

    def mute(self):
        pass

    def set_rating(self, rating):
        pass

    def get_position(self):
        pass

    def set_position(self, time):
        pass

    def get_volume(self):
        pass

    def set_volume(self, volume):
        pass
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Cli(Player):

    _timeout = 10000

    _state = CLOSED
    _track = None
    _timeout = 0

    def connect(self):
        if self._player:
            return True
        self._player = gobject.timeout_add(self._timeout,
            self.update)
        return True

    def disconnect(self):
        if self._player:
            gobject.timeout_remove(self._player)
        self._player = None

    def is_active(self, name):
        return True

    def update(self):
        if self.get_pid() != None:
            state = self.get_state()
            if state != self._state:
                self._state = state
                self.THREAD.update(STATE, self._state)
            if state <= PAUSED:
                track = self.get_track()
                if track != self._track:
                    self._track = track
                    self.THREAD.update(TRACK, self._track)
        return True

    def get_pid(self):
        raise NotImplementedError

    def get_state(self):
        raise NotImplementedError

    def get_track(self):
        raise NotImplementedError
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Mpris(Player):

    DBUS_OBJECT = '/Player' 

    capabilities = ('time', 'seek', 'volume')

    def connect(self):
        if self._player:
            return True
        try:
            proxy = dbus.SessionBus().get_object(self.DBUS_NAME, self.DBUS_OBJECT)
            self._player = dbus.Interface(proxy,
                'org.freedesktop.MediaPlayer')
            self._signals.append(self._player.connect_to_signal(
                'StatusChange', self.status_changed))
            self._signals.append(self._player.connect_to_signal(
                'TrackChange', self.track_changed))
            return True
        except:
            log.error()
            self._player = None
            return False

    def disconnect(self):
        for signal in self._signals:
            signal.remove()

        self._player = None
        self._signals = []

    def get_state(self, data=None):
        if not data:
            data = self._player.GetStatus()
        return data[0] + 1

    def get_track(self, data=None):
        if not data:
            data = self._player.GetMetadata()

        try: data['url'] = data['location']
        except: pass
        if not 'time' in data and 'mtime' in data:
            data['length'] = int(data['mtime']) /1000
        else:
            data['length'] = int(data['time'])

        return Track(data)

    def get_position(self):
        if self._player:
            return self._player.PositionGet() /1000

    def get_volume(self):
        if self._player:
            return self._player.VolumeGet()

    def set_position(self, time):
        if self._player:
            self._player.PositionSet(time *1000)

    def set_volume(self, volume):
        if self._player:
            self._player.VolumeSet(volume)

    def previous(self):
        if self._player:
            self._player.Prev()

    def play(self):
        if self._player:
            self._player.Pause()

    def next(self):
        if self._player:
            self._player.Next()

    def status_changed(self, msg):
        self.THREAD.update(STATE, self.get_state(msg))

    def track_changed(self, msg):
        self.THREAD.update(TRACK, self.get_track(msg))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Mpris2(Player):

    DB_PROPS = 'org.freedesktop.DBus.Properties'
    MP2_PATH = '/org/mpris/MediaPlayer2'
    MP2_NAME = 'org.mpris.MediaPlayer2.Player'

    capabilities = ('time', 'seek', 'volume')

    _properties = None
    _track_id = None

    def connect(self):
        if self._player:
            return True
        try:
            proxy = dbus.SessionBus().get_object(self.DBUS_NAME, self.MP2_PATH)
            self._player = dbus.Interface(proxy, self.MP2_NAME)
            self._properties = dbus.Interface(proxy, self.DB_PROPS)
            self._signals.append(self._properties.connect_to_signal(
                'PropertiesChanged', self.properties_changed))
            return True
        except:
            log.error()
            self._player = None
            return False

    def disconnect(self):
        for signal in self._signals:
            signal.remove()

        self._player = None
        self._properties = None
        self._signals = []
        self._player = False

    def get_state(self, status=None):
        if not status:
            status = self._properties.Get(self.MP2_NAME, 'PlaybackStatus')
        if status == 'Playing':
            return PLAYING
        elif status == 'Paused':
            return PAUSED
        elif status == 'Stopped':
            return STOPPED

    def get_track(self, data=None):
        if not data:
            data = self._properties.Get(self.MP2_NAME, 'Metadata')

        try:    self._track_id = data['mpris:trackid']
        except: self._track_id = None        
        try:    data['arturl'] = data['mpris:artUrl']
        except: pass
        try:    data['url'] = data['xesam:url']
        except: pass
        try:    data['artist'] = ', '.join(data['xesam:artist'])
        except: pass
        try:    data['album'] = data['xesam:album']
        except: pass
        try:    data['title'] = data['xesam:title']
        except: pass
        try:    data['tracknumber'] = data['xesam:trackNumber']
        except: pass
        try:    data['length'] = int(data['mpris:length']) /1000000
        except: pass
        try:    data['rating'] = data['xesam:userRating']
        except: pass
        try:    data['genre'] = data['xesam:genre'][0]
        except: pass
        try:    data['year'] = data['xesam:year'][0:4]
        except: pass

        return Track(data)

    def get_position(self):
        if self._player:
            return self._properties.Get(self.MP2_NAME, 'Position') /1000000

    def get_volume(self):
        if self._player:
            return self._properties.Get(self.MP2_NAME, 'Volume') *100

    def set_position(self, time):
        if self._player and self._track_id:
            self._player.SetPosition(self._track_id, time *1000000)

    def set_volume(self, volume):
        if self._player:
            return self._properties.Set(self.MP2_NAME, 'Volume', volume /100)

    def previous(self):
        if self._player:
            self._player.Previous()

    def play(self):
        if self._player:
            self._player.PlayPause()

    def next(self):
        if self._player:
            self._player.Next()

    def properties_changed(self, interface, changed, invalidated):
        if interface == self.MP2_NAME:
            if 'Metadata' in changed:
                self.THREAD.update(TRACK,
                    self.get_track(changed['Metadata']))
            if 'PlaybackStatus' in changed:
                self.THREAD.update(STATE,
                    self.get_state(changed['PlaybackStatus']))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os.path
from urllib import unquote

class Track(object):

    def __init__(self, data={}):
        for key in ('arturl','url','artist','album','title','genre'):
            if key not in data: data[key] = ''
        for key in ('tracknumber','length','rating','year'):
            if key not in data: data[key] = 0

        self.cover = \
            unquote(str(data['arturl']).encode('utf-8')).replace('file://', '')
        self.location = \
            unquote(str(data['url']).encode('utf-8')).replace('file://', '')

        self.artist = str(data['artist'])
        self.album  = str(data['album'])
        self.title  = str(data['title'])
        self.number = int(data['tracknumber'])
        self.length = int(data['length']) 
        self.rating = int(data['rating'])
        self.genre  = str(data['genre'])
        self.year   = int(data['year'])            

        if self.location and len(self.artist) <= 1:
            self.artist, self.title = self.loc2title(self.location)

    def fmt2str(self, format=''):
        return format.replace(
            '%artist',  str(getattr(self, 'artist')) ).replace(
            '%album',   str(getattr(self, 'album'))  ).replace(
            '%title',   str(getattr(self, 'title'))  ).replace(
            '%number',  str(getattr(self, 'number')) ).replace(
            '%length',  self.sec2str(getattr(self, 'length')) ).replace(
            '%',        '')

    def loc2title(self, location):
        try:
            filename, ext = os.path.splitext(os.path.basename(location))
            artist, title = filename.replace('_',' ').split(' - ')
            return artist, title
        except:
            return '', os.path.basename(location)

    def sec2str(self, seconds):
        return '%02d:%02d' % (seconds /60, seconds %60)
        #hours, seconds   = divmod(seconds, 3600)
        #minutes, seconds = divmod(seconds,   60)
        #if showHours or hours != 0:
        #    return '%u:%02u:%02u' % (hours, minutes, seconds)
        #else:
        #    return '%u:%02u' % (minutes, seconds)
