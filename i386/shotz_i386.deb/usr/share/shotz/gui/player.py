# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

from utils import prefs

class GtkDialog(gtk.Window):

    def __init__(self, widget, width, height):
        gtk.Window.__init__(self)

        self.add(widget)
        self.connect('delete-event', self.destroy)

        self.set_size_request(width, height)
        self.set_resizable(False)

        self.set_modal(True)
        self.set_skip_taskbar_hint(True)
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DIALOG)
        self.set_transient_for(prefs.Window)
        self.set_position(gtk.WIN_POS_CENTER_ON_PARENT)
        #elf.set_position(gtk.WIN_POS_MOUSE)

    def add(self, widget):
        try:
            widget.unparent()
        finally:
            gtk.Window.add(self, widget)
        widget.reparent(self)
        widget.show_all()

    def destroy(self, window, event):
        self.hide()
        return True

class GtkWindow(gtk.Window):

    _size = 640,360

    def __init__(self, args=''):
        gtk.Window.__init__(self)

        prefs.Window = self
        widget = prefs.getWidget()
        try:
            widget.unparent()
        finally:
            gtk.Window.add(self, widget)
        widget.reparent(self)
        widget.show_all()

        self.connect('delete-event', self.quit)

        self.set_icon_from_file(prefs.iconExec)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)

        self.play(args)

        gtk.main()

    def play(self, args):
        """ Instance the modules and play the given file """
        import mods
        from utils.track import Track

        mods.postMsg(mods.MSG_APP_STARTED)
        mods.postMsg(mods.CMD_PLAY, {'track': Track(args)})

    def wait(self, pending=True):
        """ Show a waiting cursor when pending events """
        self.window.set_cursor(gtk.gdk.Cursor(gtk.gdk.WATCH) \
            if pending else None)
        #while gtk.events_pending():
        #   gtk.main_iteration(False)

    def quit(self, window=None, event=0):
        """ Emitted at delete event """
        import mods

        self.hide()
        mods.postQuitMsg()
        return True
