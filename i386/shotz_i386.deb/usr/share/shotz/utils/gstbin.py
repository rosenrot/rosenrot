# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME

import gst
import urllib

class PlayBin2:

    _msg = None
    _navmsg = None
    _queue = None
    suburi = None

    def __init__(self, source, error, widget):
        self.trackStarted = source
        self.trackEnded = error

        widget.set_colormap(
            widget.get_root_window().get_screen().get_default_colormap() )
        widget.set_redraw_on_allocate(False)
        widget.set_double_buffered(False)
        widget.map()#!make sure is mapped
        #widget.modify_bg(0, widget.style.black)
        #widget.window.clear()
        self.xWindowId = widget.window.xid

        #!set gstreamer player
        self.player = gst.element_factory_make('playbin2', 'player')
        #0x0001=video, 0x0002=audio, 0x0004=text, 0x0008=vis, 0x0010=soft-volume
        #0x0020=native-audio, 0x0040=native-video
        #0x0080=download(progressive), 0x0100=buffering
        #0x0200=deinterlace, 0x0400=soft-colorbalance
        self.player.set_property('flags', 0x0001 | 0x0002)
        self.flags = self.player.get_property('flags')
        #print self.flags

        def __makeAudioSink():
            self.audiosink = gst.element_factory_make('autoaudiosink') 

            self.player.set_property('audio-sink', self.audiosink)

        def __makeVideoSink():
            self.videosink = gst.element_factory_make('xvimagesink')
            self.videosink.set_property('show-preroll-frame', False)
            self.videosink.set_property('force-aspect-ratio', True)
            self.videosink.set_property('handle-expose', True)
            self.videosink.set_property('sync', True)
            #self.videosink.expose()

            self.player.set_property('video-sink', self.videosink)

            #self.videobin = gst.Bin('videobin')
            #self.videobin.add(self.videosink)
            #!add ghostpad for link elements
            #self.videopad = gst.GhostPad('sink', self.videosink.get_pad('sink'))
            #self.videobin.add_pad(self.videopad)

        def __signalWatch():
            self.bus = self.player.get_bus()
            self.bus.add_signal_watch()
            self.bus.connect('message', self.__newBusMessage)

        __makeAudioSink(); __makeVideoSink(); __signalWatch()

        #def syncMessage(self, bus, msg): print bus, msg
        #bus.enable_sync_message_emission()
        #bus.connect('sync-message::element', self.syncMessage)
        #self.player.connect('about-to-finish', self.__aboutToFinish)
        #self.player.connect('notify::source', self.__newSource)

    def __aboutToFinish(self, bus):
        self.trackEnded(False)
        #return True

    def __newBusMessage(self, bus, msg):
        if msg.type == gst.MESSAGE_EOS:
            self.trackEnded(False)
        elif msg.type == gst.MESSAGE_ERROR:
            self.trackEnded(True)
        elif msg.type == gst.MESSAGE_ELEMENT:
            #if msg.structure.get_name() == 'prepare-xwindow-id':
            #    self.videosink.expose()
            #elif msg.structure.get_name() == 'have-xwindow-id':
            #   print msg
            if msg.structure.get_name() == 'playbin2-stream-changed':
                if msg != self._msg:
                    self.trackStarted(True)#msg.src.get_name())
                    self._msg = msg
                    #print msg
            elif msg.structure.get_name() == 'GstNavigationMessage':
                msg = dict(msg.structure)
                self._navmsg = bool(msg['type'] == 'mouse-over'
                    and msg['active'] == True)
                #print msg,self._navmsg
        elif msg.type == gst.MESSAGE_TAG:
            if msg.src.get_name() == 'dvdsrc':
                pass#self.trackStarted('False')
            elif self._navmsg != None:
                self.trackStarted('True')
            #print msg.src.get_name(), dict(msg.parse_tag())
        #elif msg.type == gst.MESSAGE_BUFFERING:
        #    if int(msg.parse_buffering()) == 100: self.trackStarted(self.uri)
        #return True

    def __newSource(self, playbin, params):
        if self.uri.startswith('cdda:'): 
            source = self.player.get_by_name('source')
            source.get_property('paranoia-mode')
            source.set_property('read-speed', 1)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def audio_tags(self):
        """ Return the audio tags """
        try: return dict(self.player.emit('get-audio-tags', 0))
        except: return {}

    def samplerate(self):
        """ Return the sample rate """
        pads = list(self.audiosink.pads())
        caps = pads[0].get_negotiated_caps()
        try: return int(caps[0]['rate'])
        except: return 0

    def duration(self):
        """ Return the duration of the stream """
        try: return int(self.player.query_duration(gst.FORMAT_TIME)[0]/1000000000)
        except: return 0

    def position(self):
        """ Return the current position """
        try: return int(self.player.query_position(gst.FORMAT_TIME)[0]/1000000000)
        except: return 0

    def state(self):
        """ Return the player state """
        #gst.STATE_VOID_PENDING=0, gst.STATE_NULL=1, gst.STATE_READY=2,
        #gst.STATE_PAUSED=3, gst.STATE_PLAYING=4
        return int(self.player.get_state()[1])

    def is_video(self):
        """ Return True if the source is a video """
        return bool(self.player.get_property('n-video') == 1)

    def video_size(self):
        """ Returns a tuple of the dimensions of the last video frame """
        #videosink = self.player.get_by_name('videosink')
        #caps = self.player.get_property('frame').get_caps()
        pads = list(self.videosink.pads())
        caps = pads[0].get_negotiated_caps()
        try: return int(caps[0]['width']), int(caps[0]['height'])
        except: return 0, 0

    def video_tags(self):
        """ Return the video tags """
        try: return dict(self.player.emit('get-video-tags', 0))
        except: return {}
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def set_uri(self, uri):
        """ Set a new source """
        self.player.set_property('uri', self.__quote(uri))
        self.uri = uri

    def __quote(self, uri):
        if uri.startswith('/'):
            try: return urllib.quote('file://' +uri.encode('utf-8'), ':/')
            except: return 'file://' +uri
        return uri

    def play(self):
        """ Play """
        self.player.set_state(gst.STATE_PLAYING)
        if self._queue:
            self.seek(self._queue)
            self._queue = 0

    def pause(self):
        """ Pause """
        self.player.set_state(gst.STATE_PAUSED)

    def stop(self):
        """ Stop """
        self.player.set_state(gst.STATE_READY)
        #!set_xwindow_id must called before play()
        self.videosink.set_xwindow_id(self.xWindowId)
        if self.suburi:
            self.player.set_property('flags', self.flags)
            self.player.set_property('suburi', '')
            self.suburi = None

    def seek(self, seconds):
        """ Seek to the given seconds """
        if self.state() == 4: 
            self.player.seek(1, gst.FORMAT_TIME,
                gst.SEEK_FLAG_FLUSH | gst.SEEK_FLAG_ACCURATE,
                gst.SEEK_TYPE_SET, int(seconds)*1000000000,
                gst.SEEK_TYPE_NONE, 0)
        else:
            self._queue = seconds

    def volume(self, level):
        """ Set the volume to the given level """
        if level >= 0.0 and level <= 1.0:
            self.player.set_property('volume', level)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def aspectRatio(self):
        """ Return the aspect ratio """
        return self.videosink.get_property('force-aspect-ratio')

    def setAspectRatio(self, value):
        """ Set the aspect ratio """
        self.videosink.set_property('force-aspect-ratio', value)
        if value: self.videosink.expose()

    def setSubUri(self, uri):
        """ Set the subtitles file to load """
        self.player.set_property('suburi', self.__quote(uri))
        self.suburi = uri
  
    def setSubFont(self, font):
        """ Set the subtitles font """
        self.player.set_property('subtitle-font-desc', font)

    def sendNavigationBtn(self, event):
        """ Send the button event """
        if self._navmsg: self.videosink.send_command(24)

    def sendNavigationKey(self, key):
        """ Send the key event, m='DVD menu' """
        keymap = {'m':1,
            'Left':20, 'Right':21, 'Up':22, 'Down':23, 'Enter':24}
        if key in keymap.keys():
            self.videosink.send_command(keymap[key])
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def getEqualizer(self, element='equalizer-3bands', rg=True):
        """Link the equalizer and replaygain elements """
        audiobin = gst.Bin('audiobin')
        audiosink = self.audiosink
        audiobin.add(audiosink)
        audiopad = gst.GhostPad('sink', self.audiosink.get_pad('sink'))
        audiobin.add_pad(audiopad)

        equalizer = gst.element_factory_make(element, 'equalizer')
        audiobin.add(equalizer)
        audiopad.set_target(equalizer.get_pad('sink')) 
        gst.element_link_many(equalizer, audiosink)

        self.player.set_property('audio-sink', audiobin)
        self.equalizer = equalizer

    def setAudioLevels(self, lvls):
        """ Set the equalizer levels, range -24/+12 """
        for i,v in enumerate(lvls):
            self.equalizer.set_property('band%s' % i, lvls[i])

    def setVideoBalance(self, lvls):
        """ Set the color balance with range -1000,1000 """
        self.videosink.set_property('brightness', lvls[0]*1000)
        self.videosink.set_property('contrast', lvls[1]*1000)
        self.videosink.set_property('saturation', lvls[2]*1000)

    def getVisPlugins(self):
        """ Return the available visual plugins """
        _list = []
        plugs = gst.registry_get_default().get_plugin_list()
        for p in plugs:
            for elem_factory \
            in gst.registry_get_default().get_feature_list_by_plugin(p.get_name()):
                if isinstance(elem_factory,gst.ElementFactory):
                    if elem_factory.get_klass().rfind('Visualization')!=-1:
                        _list.append(elem_factory.get_name())
        return _list

    def setVisPlugin(self, name):
        """ Set a new visualization plugin """
        if self.player.get_property('vis-plugin') == None:
            self.player.set_property('flags', self.flags | 0x0008)
            self.flags = self.player.get_property('flags')

        self.player.set_property('vis-plugin',
            gst.element_factory_make(name) if name else None)
