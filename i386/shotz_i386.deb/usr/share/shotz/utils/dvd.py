# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def loadDisc():
    import gudev

    client = gudev.Client(['block'])
    device_name = None
    disc_label = None

    for device in client.query_by_subsystem('block'):
        if device.has_property('ID_CDROM_MEDIA_DVD'):
            for key in device.get_property_keys():
                print "   property %s: %s" % (key, device.get_property(key))
            device_name = device.get_property('DEVNAME') 
            if device.has_property('ID_FS_LABEL'):
                disc_label = device.get_property('ID_FS_LABEL')
            else:
                disc_label = device.get_property('ID_MODEL')
            break

    if disc_label:
        from gui import niceString
        from utils.track import Track

        return Track('dvd://'+device_name, {'title': niceString(disc_label)})
    else:
        return None
