# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gobject
import pprint

import mods
from utils import gstbin, prefs

MOD_INFO = (__name__, '', True, False)

(
GST_PENDING, 
GST_NULL,
GST_READY,
GST_PAUSED,
GST_PLAYING,
) = range(5)

class Player(mods.ThreadedModule):

    _pos = 0
    _timer = None

    def __init__(self):
        self.playBin = gstbin.PlayBin2(self.__trackStarted, self.__trackEnded,
            prefs.getWidget('drawingarea1'))
        prefs.gstBin = self.playBin

        handlers = {
            mods.CMD_PLAY:          self.onPlay,
            mods.CMD_STOP:          self.onStop,
            mods.CMD_PLAY_PAUSE:    self.onTogglePause,
            mods.CMD_SEEK:          self.onSeek,
            mods.CMD_VOLUME:        self.onVolumeChanged,
            #!called by D-Bus module when is already running
            mods.CMD_TRACKS_SET: lambda tracks,playNow: self.onPlay(tracks[0]),
            #!called to quit application at end of track
            mods.MSG_ENDED:         self.onStop,
            mods.MSG_ERROR:         self.onStop,
                   }
        mods.ThreadedModule.__init__(self, handlers)

    def __startTimer(self):
        if not self._timer:
            self._timer = gobject.timeout_add(1000, self.__updateTimer)

    def __stopTimer(self):
        if self._timer:
            gobject.source_remove(self._timer)
        self._timer = None

    def __updateTimer(self):       
        pos = self.playBin.position()
        if pos != self._pos:
            self._pos = pos
            mods.postMsg(mods.MSG_NEW_POSITION, {'seconds': pos})
        return True

    def __trackEnded(self, error):
        if error and self._pos >= 0:
            self._pos = -1
            mods.postMsg(mods.MSG_ERROR)

        elif self._pos > 0:
            self._pos = 0
            mods.postMsg(mods.MSG_ENDED)

    def __trackStarted(self, playing):
        tags = self.playBin.audio_tags()
        tags['length'] = self.playBin.duration()       
        tags['samplerate'] = self.playBin.samplerate()
        tags.update(self.playBin.video_tags())
        if 'video-codec' in tags.keys():
            tags['video-size'] = '%dx%d' % self.playBin.video_size()
        elif self.track.path.startswith('cdda:'):
            pass
        elif self.track.path.startswith('dvd:'):
            tags['video-codec'] = u'DVD'
            tags['video-size'] = '16x9'
            #print msg, tags['title'].startswith('DVD Menu')
            #if tags['title'].startswith('DVD Menu'):
            tags['length'] = 0
            tags['title'] = self.track.tags['title']
            self.__stopTimer()
        elif not self.track.path.startswith('/'):
            try: tags['title'] = tags['organization']
            finally: tags['length'] = 0

        [tags.pop(k) for k in tags.keys() if not pprint.isreadable(tags[k])]
        print '<gst.tags> %s' % str(tags)[1:-1]

        self.track.tags = tags

        if int(tags['length']) > 0:
            self.__startTimer()

        mods.postMsg(mods.MSG_NEW_TRACK, {'track': self.track})
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onPlay(self, track):
        self._pos = 0
        self.track = track

        self.playBin.stop()
        self.playBin.set_uri(track.path)
        self.playBin.play()

    def onStop(self):
        self._pos = 0
        self.__stopTimer()

        self.playBin.stop()
        mods.postMsg(mods.MSG_STOPPED)

    def onTogglePause(self):
        state = self.playBin.state()
        if state == GST_PAUSED:
            self.playBin.play()
            mods.postMsg(mods.MSG_UNPAUSED)

        elif state == GST_PLAYING:
            self.playBin.pause()
            mods.postMsg(mods.MSG_PAUSED)

    def onSeek(self, seconds):
        self.playBin.seek(seconds)

    def onVolumeChanged(self, level):
        self.playBin.volume(level)
