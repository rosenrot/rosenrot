# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

class GtkDialog(gtk.Window):

    def __init__(self, parent, width, height):
        gtk.Window.__init__(self)

        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DIALOG)
        self.set_size_request(width, height)
        self.set_skip_taskbar_hint(True)
        #self.set_position(gtk.WIN_POS_CENTER_ON_PARENT)
        #self.set_transient_for(parent)
        #self.set_modal(True)
        self.connect('delete-event', self.__hide)

    def add(self, widget):
        try: widget.unparent()
        finally: gtk.Window.add(self, widget)
        widget.reparent(self)

    def __hide(self, window, event):
        self.hide()
        return True
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class TextBuffer(gtk.TextBuffer):

    def __init__(self):
        gtk.TextBuffer.__init__(self)

    def get_container(self):
        textview = gtk.TextView()
        textview.set_cursor_visible(False)
        textview.set_editable(False)
        textview.set_left_margin(6)
        textview.set_wrap_mode(gtk.WRAP_WORD)
        textview.set_overwrite(False)
        textview.set_buffer(self)

        return textview
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class TextDialog(GtkDialog):

    def __init__(self, parent=None, width=400, height=250):
        GtkDialog.__init__(self, parent, width, height)

        scrolled = gtk.ScrolledWindow()

        scrolled.set_shadow_type(gtk.SHADOW_NONE)#IN)
        scrolled.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)

        vbox = gtk.VBox()
        vbox.pack_start(scrolled, True, True, 2)

        self.add(vbox)
        self.text = TextBuffer()

        scrolled.add(self.text.get_container())

    def set_text(self, text):
        self.text.set_text(text)
