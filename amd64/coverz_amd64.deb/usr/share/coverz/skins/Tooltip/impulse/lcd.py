import math

fft = True
pwr = 0.7 # 0.1/0.9

width = 280
height = 80

peak_heights = [0 for i in range(256)]
peak_acceleration = [0.0 for i in range(256)]

bar_color = 0.75, 0.75, 0.75, 0.65
bg_color = 0.25, 0.25, 0.25, 0.65
peak_color = 1.0, 1.0, 1.0, 0.8

n_cols = 15
col_width = 16
col_spacing = 1

n_rows = 22
row_height = 2
row_spacing = 1

def get_audio_value(sample):
    factor = sample
    if pwr:
        factor = math.pow(sample, 1.0 -pwr)
        #factor = math.sin(math.pi /2 *sample)
    return int(factor *(n_rows -1))

def on_draw(audio_sample_array, cr, widget):
    freq = len(audio_sample_array) /(n_cols -1)

    cr.set_source_rgba(bar_color[0], bar_color[1], bar_color[2], bar_color[3])
    for i in range(0, len(audio_sample_array), freq):
        col = i /freq
        #rows = int(audio_sample_array[i] *(n_rows -2))
        rows = get_audio_value(audio_sample_array[i])

        for row in range(0, rows):
            cr.rectangle(
                col *(col_width+ col_spacing),
                widget.get_height() -row *(row_height+ row_spacing),
                col_width, -row_height)
    cr.fill()

    cr.set_source_rgba(bg_color[0], bg_color[1], bg_color[2], bg_color[3])
    for i in range(0, len(audio_sample_array), freq):
        col = i /freq
        #rows = int(audio_sample_array[i] *(n_rows -2))
        rows = get_audio_value(audio_sample_array[i])

        for row in range(rows, n_rows):
            cr.rectangle(
                col *(col_width+ col_spacing),
                widget.get_height() -row *(row_height+ row_spacing),
                col_width, -row_height)
    cr.fill()

    cr.set_source_rgba(peak_color[0], peak_color[1], peak_color[2], peak_color[3])

    for i in range(0, len(audio_sample_array), freq):
        col = i /freq
        #rows = int(audio_sample_array[i] *(n_rows -2))
        rows = get_audio_value(audio_sample_array[i])

        if rows > peak_heights[i]:
            peak_heights[i] = rows
            peak_acceleration[i] = 0.0
        else:
            peak_acceleration[i]+= .1
            peak_heights[i] -= peak_acceleration[i]

        if peak_heights[i] < 0:
            peak_heights[i] = 0

        cr.rectangle(
            col *(col_width+ col_spacing),
            widget.get_height() -peak_heights[i] *(row_height+ row_spacing),
            col_width, -row_height)
    cr.fill()

    cr.fill()
    cr.stroke()
