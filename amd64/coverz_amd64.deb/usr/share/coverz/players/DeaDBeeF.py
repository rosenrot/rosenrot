# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

from subprocess import Popen, PIPE

from players import Cli, Track, PLAYING, STOPPED

class DeaDBeeF(Cli):

    __doc__ = 'DeaDBeeF 0.5 plugin'

    _exec = '/opt/deadbeef/bin/deadbeef'
    _data = {}

    def _get_output(self):
        p = Popen([self._exec, '--nowplaying','%a\t%b\t%t\t%l\t%F'],
            stdout=PIPE, stderr=PIPE)
        output = p.communicate()[0]

        if output == 'nothing':
            return STOPPED
        else:
            self._data = self._get_track(output)
            return PLAYING

    def get_pid(self):
        return Popen(['pidof', self._exec], stdout=PIPE).communicate()[0].strip()

    def get_state(self):
        return self._get_output()

    def _get_track(self, output):
        vals = output.split('\t')
        data = {}
        for n,key in enumerate(['artist','album','title','length','url']):
            if key == 'length':
                mins,secs = vals[n].split(':')
                data[key] = int(mins) *60 +int(secs)
            else:
                data[key] = vals[n]
        return data

    def get_track(self):
        return Track(self._data)

    def previous(self):
        Popen([self._exec, '--prev'])

    def next(self):
        Popen([self._exec, '--next'])

    def play(self):
        Popen([self._exec, '--play-pause'])
