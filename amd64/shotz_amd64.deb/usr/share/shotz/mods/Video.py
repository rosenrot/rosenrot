# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME
import gtk
import gobject

import mods
from utils import prefs

MOD_INFO = (__name__, '', True, False)

class Video(mods.Module):

    _video  = False
    _motion = None
    _timer  = None
    _zoom   = 1.0
    track   = None

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:   self.onAppStarted,
            mods.MSG_APP_QUIT:      self.onAppQuit,
            mods.MSG_NEW_TRACK:     self.onNewTrack,
            mods.MSG_STOPPED:       self.onStopped,
                   }
        mods.Module.__init__(self, handlers)

    def onAppStarted(self):
        """ The application is started """
        self.window = prefs.Window
        self.window.connect('window-state-event', self.onNewState)
        widget = prefs.getWidget

        self.ctrpanel = widget('hbox2')
        self._panel = self.ctrpanel.get_allocation()

        self.drawarea = widget('drawingarea1')
        self.drawarea.modify_bg(gtk.STATE_NORMAL, self.drawarea.style.black)
        self.drawarea.window.clear()

        self.drawarea.drag_dest_set(gtk.DEST_DEFAULT_ALL,
            [('text/uri-list', 0, 1)], gtk.gdk.ACTION_COPY)
        self.drawarea.connect('drag-data-received', self.onDND)
        self.drawarea.connect('button-press-event', self.onButtonPress)
        self.drawarea.connect('scroll-event', self.onScrollEvent)
        self.drawarea.connect('key-press-event', self.onKeyPress)

        self.playBin = prefs.gstBin
        self._vis = prefs.get('visual-plugin', 'goom')
        if self._vis:
            self.playBin.setVisPlugin(self._vis)
        self.plugins = self.playBin.getVisPlugins()

    def onAppQuit(self):
        """ The application is about to quit """
        prefs.set('visual-plugin', self._vis)      
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onNewTrack(self, track):
        """ A new track is being played """
        self.track = track
        self._video = bool('video-codec' in track.tags.keys())
        try:
            self._vsize = [float(v) for v in track.tags['video-size'].split('x')]
        except:
            self._vsize = 640.0, 360.0 #-self._panel.height 
        self.__resize()

        self.playBin.setAspectRatio(self._video)

        gobject.idle_add(self.window.show_all)

    def onStopped(self, error=False):
        """ The playback has been stopped """
        self.window.unfullscreen()
        #FIXME
        self.window.emit('delete-event', gtk.gdk.Event(gtk.gdk.DESTROY))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onFitSize(self):
        """ Fit the window height to the video """
        drawarea = self.drawarea.get_allocation()
        dw,dh = float(drawarea.width), float(drawarea.height)
        iw,ih = self._vsize
        ow,oh = dw, dw*ih/iw

        self._zoom = round(oh/ih, 1)
        self._resize(ow,oh)

    def onScrollEvent(self, widget, event):
        """ Emitted on scrolling into the drawing area """
        if event.direction == gtk.gdk.SCROLL_UP:
             self.zoom(+0.2)
        else:
             self.zoom(-0.2)

    def __resize(self):
        sw,sh = gtk.gdk.screen_width() *0.85, gtk.gdk.screen_height() *0.85
        iw,ih = self._vsize
        if iw < sw and ih < sh:
            ow,oh = iw,ih
        else:
            ow,oh = 640, 640*ih/iw

        self._zoom = round(oh/ih, 1)

        self.window.resize(int(ow), int(oh) +self._panel.height)

    def _resize(self, ow, oh):
        #self.drawarea.size_allocate(gtk.gdk.Rectangle(0, 0, int(ow), int(oh)))
        #self.drawarea.set_size_request(int(ow), int(oh))
        self.window.resize(int(ow), int(oh) +self._panel.height)
        #print ow,oh
        #gobject.idle_add(self.drawarea.set_size_request, -1, -1)

    def zoom(self, factor):
        zoom = sum([self._zoom, factor])
        ow,oh = [v*zoom for v in self._vsize]

        screen = self.window.get_screen()
        if ow > screen.get_width() *0.85 or oh > screen.get_height() *0.85:
            return
        elif ow < 480:
            ow,oh = 480, 480*oh/ow
        else:
            self._zoom = zoom
        self._resize(ow,oh)

    def onNewState(self, window, event):
        """ Emitted when the window change state """
        if event.new_window_state == gtk.gdk.WINDOW_STATE_FULLSCREEN:
            self._motion = window.connect('motion-notify-event',
                lambda w,e: self.showCursor())
            self.hideCursor()
        else:
            if self._motion != None:
                window.disconnect(self._motion)
            self._motion = None
            self.showCursor(exit=True)
        return False

    def _noCursor(self):
        pixmap, color = gtk.gdk.Pixmap(None, 1, 1, 1), gtk.gdk.Color()
        return gtk.gdk.Cursor(pixmap, pixmap, color, color, 0, 0)

    def hideCursor(self):
        if self._timer != None:
            gobject.source_remove(self._timer)
        self._timer = None

        self.drawarea.window.set_cursor(self._noCursor()) 
        self.ctrpanel.hide()

    def showCursor(self, exit=False):
        if self._timer != None:
            gobject.source_remove(self._timer)
        self._timer = None if exit else \
            gobject.timeout_add(2400, self.hideCursor)

        self.drawarea.window.set_cursor(None)
        self.ctrpanel.show()

    def _showSubtitles(self):
        from gui import listDir

        file = None
        dir = self.track.getDirName()
        for (name, path) in listDir(dir):
            if name[-4:].lower() in ('.idx','.ssa','.srt','.sub','.txt'):
                file = path
                if name[:-4] in self.track.getFileName():
                    break
        if file:
            self.playBin.stop()
            self.playBin.player.set_property('flags', self.playBin.flags | 0x0004)
            self.playBin.setSubUri(file)
            self.playBin.setSubFont('Droid Sans Fallback 10')
            self.playBin.play()

    def _visMenu(self, menu):
        def _set(w, vis):
            self.playBin.setVisPlugin(vis)
            self._vis = vis

        for name in sorted(self.plugins):
            item = gtk.CheckMenuItem(
                name.replace('visual_', '').replace('lib', '').title())
            item.set_active(name == self._vis)
            item.connect('activate', _set, name)
            menu.append(item)

    def _visNext(self):
        for n,i in enumerate(sorted(self.plugins)):
            if self._vis == i:
                try: self._vis = self.plugins[n+1]
                except: self._vis = self.plugins[0]
                break
        self.playBin.setVisPlugin(self._vis)

    def _videoMenu(self, menu):
        from gettext import gettext as _

        menu.append(gtk.SeparatorMenuItem())
        esc = gtk.ImageMenuItem(gtk.STOCK_CLOSE)
        esc.connect('activate', lambda w: self.window.emit('delete-event',
            gtk.gdk.Event(gtk.gdk.DESTROY)))
        menu.append(esc)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onDND(self, widget, context, x, y, dragData, dndId, time):
        """ Emitted on Drag'n'Drop """
        from utils import getTracksFromDnd

        tracks = getTracksFromDnd(dragData, dndId)
        if tracks:
            mods.postMsg(mods.CMD_TRACKS_SET, {
            'tracks': tracks, 'playNow': True})

    def onButtonPress(self, widget, event):
        """ Emitted when the drawing area is clicked """
        button = int(event.button)
        state = self.window.window.get_state()
        if button == 1 and event.type == gtk.gdk._2BUTTON_PRESS:
            self.window.unfullscreen() \
            if state == gtk.gdk.WINDOW_STATE_FULLSCREEN \
            else self.window.fullscreen()
            return

        elif self.track and self.track.path.startswith('dvd'):
            if button == 1:
                self.playBin.sendNavigationBtn(event.button)
            elif button == 3:
                self.playBin.sendNavigationKey('m')

        elif button == 3:
            menu = gtk.Menu()

            if self._video:
                return#FIXME
            self._visMenu(menu)

            menu.show_all()
            menu.popup(None, None, None, 3, event.get_time(), 0)
        elif button == 2:
            self.__resize()

    def onKeyPress(self, widget, event):
        """ Emitted when a key is pressed """
        key = gtk.gdk.keyval_name(event.keyval)
        if self.track and self.track.path.startswith('dvd'):
            self.playBin.sendNavigationKey(key)
        elif key == 'e':
            prefs.getWidget('btn-eq').emit('clicked')
        elif key == 's' and self._video:
            self._showSubtitles()
        elif key == 'Escape':
            if self.window.window.get_state() != gtk.gdk.WINDOW_STATE_FULLSCREEN:
                #FIXME
                self.window.emit('delete-event', gtk.gdk.Event(gtk.gdk.DESTROY))
                #self.window.onQuit()
            self.window.unfullscreen()
        #print key
