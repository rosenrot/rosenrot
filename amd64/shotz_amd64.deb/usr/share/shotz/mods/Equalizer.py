# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME
import gobject

import mods
from utils import prefs

MOD_INFO = (__name__, '', False, False)#!True

class Equalizer(mods.Module):

    dialog = None

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED: gobject.idle_add(self.onAppStarted),
            #mods.MSG_APP_QUIT:     self.onAppQuit,
                   }
        mods.Module.__init__(self, handlers)

    def __audioEqChanged(self, w):
        self.audioEq[w] = w.get_value()
        self.playBin.setAudioLevels(list(reversed(self.audioEq.values())))

    def __videoEqChanged(self, w):
        self.videoEq[w] = w.get_value()
        self.playBin.setVideoBalance(self.videoEq.values())

    def __setEqRange(self):
        audioEq = prefs.get('eq-audio-lvls', [0, 0, 0])
        self.audioEq = {}          

        for n in xrange(3):
            w = self.eqGlade.get_object('vscale' +str(n))
            w.set_range(-12, 12)
            w.set_value(audioEq[n])
            w.connect('value-changed', self.__audioEqChanged)

            self.audioEq[w] = w.get_value()

        videoEq = prefs.get('eq-video-lvls', [0, 0, 0])
        self.videoEq = {}

        for n in xrange(3):
            w = self.eqGlade.get_object('hscale' +str(n))
            w.set_range(-0.7, 0.7)#(-1, 1)
            w.set_value(videoEq[n])
            w.connect('value-changed', self.__videoEqChanged)

            self.videoEq[w] = w.get_value()

    def __resetEq(self):
        for w in self.audioEq.keys(): w.set_value(0)
        self.playBin.setAudioLevels([0, 0, 0])

        for w in self.videoEq.keys(): w.set_value(0)
        self.playBin.setVideoBalance([0, 0, 0])
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onAppStarted(self):
        """ The application is started """
        self.playBin = prefs.gstBin

        self.playBin.getEqualizer()
        self.playBin.setAudioLevels([v for v in reversed(
            prefs.get('eq-audio-lvls', [0, 0, 0]))])
        self.playBin.setVideoBalance(
            prefs.get('eq-video-lvls', [0, 0, 0]))

        prefs.getWidget('btn-eq').connect('clicked', self.onShowEqualizer)
        
    def onAppQuit(self):
        """ The application is about to terminate """
        if self.dialog:
            prefs.set('eq-audio-lvls', self.audioEq.values())
            prefs.set('eq-video-lvls', self.videoEq.values())
        else:
            prefs.set('eq-audio-lvls', [0, 0, 0])
            prefs.set('eq-video-lvls', [0, 0, 0])

    def __newState(self, window, event):
        new_state = event.new_window_state
        if new_state != 0:
            self.dialog.hide()

    def onShowEqualizer(self, item):
        """ Shot the Equalizer dialog window """
        if not self.dialog:
            import gtk
            from gettext import gettext as _

            self.window = prefs.Window
            #self.window.connect('window-state-event', self.__newState)

            self.eqGlade = prefs.setGlade('glade-eq.xml')

            from gui.player import GtkDialog
            self.dialog = GtkDialog(self.eqGlade.get_object('vbox1'), 128, -1)

            self.dialog.set_title(_('Equalizer')) 
            #self.set_decorated(False)
            #self.set_opacity(0.95)
            """
            def __save_eq():
                prefs.set('eq-audio-lvls', self.audioEq.values())
                prefs.set('eq-video-lvls', self.videoEq.values())
                self.dialog.emit('delete-event', None)
            save = self.eqGlade.get_object('btn-close')
            save.connect('button-press-event',
                lambda w,e: __save_eq())
            undo = self.eqGlade.get_object('btn-menu')
            undo.connect('button-press-event',
                lambda w,e: self.__resetEq())
            close = self.eqGlade.get_object('btn-close')
            close.connect('button-press-event',
                lambda w,e: self.dialog.emit('delete-event', None))
            #!translate
            for (w,l) in (
                ('h',_('High')),('m',_('Mid')),('l',_('Low')),
                ('b',_('Brns')),('c',_('Crt')),('s',_('Sat')),):
                self.eqGlade.get_object(w).set_label(l)
            """
            #!set default ranges
            self.__setEqRange()

        self.dialog.show()
        #eq = self.dialog.get_allocation()
        #(x,y), (w,h) = self.window.get_position(), self.window.get_size()
        #self.dialog.move(x +w -eq.width, y +h -eq.height)
