# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
import os.path
import urllib
import webkit

from gui import iconExec, size2str

class GtkWindow(gtk.Window):

    def __init__(self, file):
        gtk.Window.__init__(self)

        header = swfparse(file)#{'width':640,'height':480,'size':0,}
        iw,ih = header['width'],header['height']
        sw,sh = gtk.gdk.screen_width() *0.85, gtk.gdk.screen_height() *0.85
        if iw > sw: ow,oh = sw, ih*sw/iw
        else: ow,oh = iw,ih
        if oh > sh: ow,oh = iw*sh/ih, sh
        elif iw < 480: ow,oh = 480, 480*ih/iw

        web = webkit.WebView()
        #sets = web.get_settings()
        #sets.set_property('auto-resize-window', True)
        #sets.set_property('enable-universal-access-from-file-uris', True)
        web.load_uri(self.__quote(file))

        self.add(web)
        self.connect('delete-event', self.onQuit)

        self.set_icon_from_file(iconExec)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        self.set_title('%s ! %sx%s %s' % (
            file[file.rfind('/')+1:],
            header['width'],
            header['height'],
            size2str(header['size']),))
        #self.set_tooltip_text(...
        self.show_all()
        self.set_size_request(int(ow),int(oh))        
        self.set_resizable(False)

        gtk.main()

    def onQuit(self, window, event):
        gtk.main_quit()
        return True

    def __quote(self, uri):
        uri = os.path.abspath(uri)
        if uri.startswith('/'):
            try: return urllib.quote('file://'+uri.encode('utf-8'), ':/')
            except: return 'file://' +uri
        return uri
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
# author-email: kai.lautaportti@hexagonit.fi

import zlib
import struct

def swfparse(file):
    """Parses the header information from the given SWF file """
    if hasattr(file, 'read'):
        input.seek(0)
    else:
        input = open(file, 'rb')

    def read_ui8(c):
        return struct.unpack('<B', c)[0]
    def read_ui16(c):
        return struct.unpack('<H', c)[0]
    def read_ui32(c):
        return struct.unpack('<I', c)[0]

    header = {}
    # read the 3-byte signature field
    signature = ''.join(struct.unpack('<3c', input.read(3)))
    if signature not in ('FWS', 'CWS'):
        raise ValueError('Invalid SWF signature: %s' % signature)

    # compression
    header['compressed'] = signature.startswith('C')

    # version
    header['version'] = read_ui8(input.read(1))

    # size (stored as a 32-bit integer)
    header['size'] = read_ui32(input.read(4))
    buffer = input.read(header['size'])
    if header['compressed']:
        # unpack the zlib compression
        buffer = zlib.decompress(buffer)

    # containing rectangle (struct RECT), each of the RECT values are stored in
    # first five bits of the first byte.
    nbits = read_ui8(buffer[0]) >> 3

    current_byte, buffer = read_ui8(buffer[0]), buffer[1:]
    bit_cursor = 5

    for item in 'xmin', 'xmax', 'ymin', 'ymax':
        value = 0
        for value_bit in range(nbits-1, -1, -1): # == reversed(range(nbits))
            if (current_byte << bit_cursor) & 0x80:
                value |= 1 << value_bit
            # advance the bit cursor to the next bit
            bit_cursor += 1

            if bit_cursor > 7:
                # exhausted the current byte, consume the next one
                current_byte, buffer = read_ui8(buffer[0]), buffer[1:]
                bit_cursor = 0

        # convert value from TWIPS to a pixel value
        header[item] = value / 20

    header['width'] = header['xmax'] -header['xmin']
    header['height'] = header['ymax'] -header['ymin']
    
    header['frames'] = read_ui16(buffer[0:2])
    header['fps'] = read_ui16(buffer[2:4])

    input.close()
    pprint(file, header)

    return header

def pprint(input, header):
    print '<swf.tags> %s' % str(header)[1:-1]
