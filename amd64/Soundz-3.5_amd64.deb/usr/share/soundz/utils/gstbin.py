# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gst
import urllib

class PlayBin2:

    _queue = 0

    def __init__(self, source, error):
        """ Initialize the player """
        self.trackStarted = source
        self.trackEnded = error
        self.queueSeek = None
        self.lastMsg = None

        self.player = gst.element_factory_make('playbin2', 'player')
        self.player.set_property('flags', 0x0002)

        def __makeAudioSink():
            self.audiosink = gst.element_factory_make('autoaudiosink', 'sink') 
            self.player.set_property('audio-sink', self.audiosink)

        def __makeFakeSink():
            self.videosink = gst.element_factory_make('fakesink')
            self.videosink.set_property('sync', True)
            self.player.set_property('video-sink', self.videosink)

        __makeAudioSink()#; __makeFakeSink()

        self.player.connect('about-to-finish', self.__aboutToFinish)

        bus = self.player.get_bus()
        bus.add_signal_watch()
        bus.connect('message', self.__newBusMessage)

    def __aboutToFinish(self, bus):
        self.trackEnded(False)

    def __newBusMessage(self, bus, msg):
        if msg.type == gst.MESSAGE_EOS:
            self.trackEnded(False)
        elif msg.type == gst.MESSAGE_ERROR:
            self.trackEnded(True)
        elif msg.type == gst.MESSAGE_ASYNC_DONE:
            if self.uri: self.trackStarted(True)
            self.uri = None

    def add_equalizer(self, element='equalizer-10bands', rg=True):
        """Link the equalizer and replaygain elements """
        audiobin = gst.Bin('audiobin')
        audiosink = self.audiosink
        audiobin.add(audiosink)
        audiopad = gst.GhostPad('sink', self.audiosink.get_pad('sink'))
        audiobin.add_pad(audiopad)

        equalizer = gst.element_factory_make(element, 'equalizer')
        rgvolume = gst.element_factory_make('rgvolume', 'replaygain')
        rgvolume.set_property('album-mode', False)

        audiobin.add(equalizer, rgvolume)
        audiopad.set_target(equalizer.get_pad('sink'))
        audiopad.set_target(rgvolume.get_pad('sink')) 
        gst.element_link_many(rgvolume, equalizer, audiosink)

        self.player.set_property('audio-sink', audiobin)
        self.equalizer = equalizer

    def audio_tags(self):
        """ Return the audio tags """
        try: return dict(self.player.emit('get-audio-tags', 0))
        except: return {}

    def samplerate(self):
        """ Return the sample rate """
        pads = list(self.audiosink.pads())
        caps = pads[0].get_negotiated_caps()
        try: return int(caps[0]['rate'])
        except: return 0

    def duration(self):
        """ Return the duration of the stream """
        try: return int(self.player.query_duration(gst.FORMAT_TIME)[0]/1000000000)
        except: return 0

    def position(self):
        """ Return the current position """
        try: return int(self.player.query_position(gst.FORMAT_TIME)[0]/1000000000)
        except: return 0

    def state(self):
        """ Return the player state """
        #gst.STATE_VOID_PENDING=0, gst.STATE_NULL=1, gst.STATE_READY=2,
        #gst.STATE_PAUSED=3, gst.STATE_PLAYING=4
        return int(self.player.get_state()[1])

    def set_uri(self, uri):
        """ Set a new source """
        self.player.set_property('uri', self.__quote(uri))
        self.uri = uri

    def __quote(self, uri):
        if uri.startswith('/'):
            try: return urllib.quote('file://' +uri.encode('utf-8'), ':/')
            except: return 'file://' +uri
        return uri

    def play(self):
        """ Play """
        self.player.set_state(gst.STATE_PLAYING)
        if self._queue:
            self.seek(self._queue)
            self._queue = 0

    def pause(self):
        """ Pause """
        self.player.set_state(gst.STATE_PAUSED)

    def stop(self):
        """ Stop """
        self.player.set_state(gst.STATE_READY)

    def seek(self, seconds):
        """ Seek to the given seconds """
        if self.state() == 4: 
            self.player.seek(1, gst.FORMAT_TIME,
                gst.SEEK_FLAG_FLUSH | gst.SEEK_FLAG_ACCURATE,
                gst.SEEK_TYPE_SET, int(seconds)*1000000000,
                gst.SEEK_TYPE_NONE, 0)
        else:
            self._queue = seconds

    def volume(self, level):
        """ Set the volume to the given level """
        if level >= 0.0 and level <= 1.0:
            self.player.set_property('volume', level)
