# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def getTrack(filename):
    """ Return a Track created from an mp4 file """
    from mutagen.mp4 import MP4

    mp4File = MP4(filename)

    length     = int(round(mp4File.info.length))
    bitrate    = int(mp4File.info.bitrate)
    samplerate = int(mp4File.info.sample_rate)

    try:    artist = str(mp4File['\xa9ART'][0])
    except: artist = None

    try:    album = str(mp4File['\xa9alb'][0])
    except: album = None

    try:    title = str(mp4File['\xa9nam'][0])
    except: title = None

    try:    number = str(mp4File['trkn'][0][0])
    except: number = None

    try:    date = str(mp4File['\xa9day'][0][0])
    except: date = None

    try:    genre = str(mp4File['\xa9gen'][0])
    except: genre = None

    return filename, length, bitrate, artist, album, title
