# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def getTrack(filename):
    """ Return a Track created from a WavPack file """
    from mutagen.wavpack import WavPack

    wvFile = WavPack(filename)

    length     = int(round(wvFile.info.length))
    samplerate = int(wvFile.info.sample_rate)

    try:    artist = str(wvFile['Artist'][0])
    except: artist = None

    try:    album = str(wvFile['Album'][0])
    except: album = None

    try:    title = str(wvFile['Title'][0])
    except: title = None

    try:    number = str(wvFile['Track'][0])
    except: number = None

    try:    date = str(wvFile['Year'][0])
    except: date = None

    try:    genre = str(wvFile['genre'][0])
    except: genre = None

    return filename, length, bitrate, artist, album, title
