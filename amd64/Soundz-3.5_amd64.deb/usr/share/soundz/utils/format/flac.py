# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def getTrack(filename):
    """ Return a Track created from a FLAC file """
    from mutagen.flac import FLAC

    flacFile = FLAC(filename)

    length     = int(round(flacFile.info.length))
    samplerate = int(flacFile.info.sample_rate)

    try:    artist = str(flacFile['artist'][0])
    except: artist = None

    try:    album = str(flacFile['album'][0])
    except: album = None

    try:    title = str(flacFile['title'][0])
    except: title = None

    try:    number = str(flacFile['tracknumber'][0])
    except: number = None

    try:    date = str(flacFile['date'][0])
    except: date = None

    try:    genre = str(flacFile['genre'][0])
    except: genre = None

    return filename, length, bitrate, artist, album, title
