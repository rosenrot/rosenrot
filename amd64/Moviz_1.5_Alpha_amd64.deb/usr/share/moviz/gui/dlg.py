# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

from utils import prefs

__currDir = prefs.dirUsr
__parent  = prefs.Window

def openFile(select=False, dir=None):
    """ Return a file path, or a dir path if 'select' is True """
    global __currDir

    dlg = gtk.FileChooserDialog(
        __stock(gtk.STOCK_OPEN), __parent,
        gtk.FILE_CHOOSER_ACTION_OPEN \
        if not select else gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))
    dlg.set_current_folder(__currDir if dir == None else dir)
    dlg.set_select_multiple(False)

    file = None
    if dlg.run() == gtk.RESPONSE_OK:
        file = dlg.get_filename()
    __currDir = dlg.get_current_folder()
    dlg.destroy()

    return file

def openURI():
    """ Return a pathname from an entry widget """
    dlg = gtk.Dialog(__stock(gtk.STOCK_OPEN), __parent,
        gtk.DIALOG_MODAL,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OK, gtk.RESPONSE_OK))

    entry = gtk.Entry()
    try: entry.set_text(gtk.clipboard_get().wait_for_text())
    except: pass
    hbox = gtk.HBox()
    hbox.pack_start(entry, True, True, 6)

    dlg.get_content_area().pack_start(hbox, True, True, 6)
    dlg.set_default_size(300, 1)
    if dlg.run() == gtk.RESPONSE_OK:
        file = entry.get_text()    
    dlg.destroy()

    return file

def saveFile(file):
    """ Return a file path """
    dlg = gtk.FileChooserDialog(
        __stock(gtk.STOCK_SAVE_AS), __parent,
        gtk.FILE_CHOOSER_ACTION_SAVE,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))
    dlg.set_do_overwrite_confirmation(True)
    dlg.set_select_multiple(False)
    dlg.set_current_folder(file[:file.rfind('/')])
    dlg.set_current_name(file[file.rfind('/')+1:])

    file = None
    if dlg.run() == gtk.RESPONSE_OK:
        file = dlg.get_filename()
    __currDir = dlg.get_current_folder()
    dlg.destroy()

    return file

def __stock(stockid):
    """ Return the translated label of a stock id """
    return gtk.stock_lookup(stockid)[1].replace('_', '')

def __msgBox(dlgtype, buttons, header, text):
    """ Show a message dialog box
        if dlgtype == gtk.MESSAGE_INFO or dlgtype == gtk.MESSAGE_ERROR,
        gtk.BUTTONS_OK,
        elif dlgtype == gtk.MESSAGE_QUESTION,
        gtk.BUTTONS_YES_NO,
    """
    dlg = gtk.MessageDialog(prefs.Window,
        gtk.DIALOG_MODAL, dlgtype, buttons, header)
    dlg.set_border_width(12)
    dlg.set_title('')

    if text: dlg.format_secondary_markup(text)
    else: dlg.set_markup(header)

    response = dlg.run()
    dlg.destroy()
