# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import mods
from utils import prefs

MOD_INFO = (__name__, '', True, False)
EQDLG = prefs.setGlade('eq.xml')

class Equalizer(mods.Module):

    EqDlg = None

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:   self.onAppStarted,
            #mods.MSG_APP_QUIT:     self.onAppQuit,
                   }
        mods.Module.__init__(self, handlers)

    def __audioEqChanged(self, w):
        self.audioEq[w] = w.get_value()
        self.playBin.setAudioLevels(list(reversed(self.audioEq.values())))

    def __videoEqChanged(self, w):
        self.videoEq[w] = w.get_value()
        self.playBin.setVideoBalance(self.videoEq.values())

    def __setEqRange(self):
        audioEq = prefs.get('eq-audio-lvls', [0, 0, 0])
        self.audioEq = {}          

        for n in xrange(3):
            w = EQDLG.get_object('vscale' +str(n))
            w.set_range(-12, 12)
            w.set_value(audioEq[n])
            w.connect('value-changed', self.__audioEqChanged)

            self.audioEq[w] = w.get_value()

        videoEq = prefs.get('eq-video-lvls', [0, 0, 0])
        self.videoEq = {}

        for n in xrange(3):
            w = EQDLG.get_object('hscale' +str(n))
            w.set_range(-0.7, 0.7)#(-1, 1)
            w.set_value(videoEq[n])
            w.connect('value-changed', self.__videoEqChanged)

            self.videoEq[w] = w.get_value()

    def __resetEq(self):
        for w in self.audioEq.keys(): w.set_value(0)
        self.playBin.setAudioLevels([0, 0, 0])

        for w in self.videoEq.keys(): w.set_value(0)
        self.playBin.setVideoBalance([0, 0, 0])
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onAppStarted(self):
        """ The application is started """
        self.playBin = prefs.gstBin

        self.playBin.initEqualizer()
        self.playBin.setAudioLevels([v for v in reversed(
            prefs.get('eq-audio-lvls', [0, 0, 0]))])
        self.playBin.setVideoBalance(
            prefs.get('eq-video-lvls', [0, 0, 0]))

        prefs.getWidget('btn-eq').connect('clicked', self.onShowEqualizer)
        
    def onAppQuit(self):
        """ The application is about to terminate """
        if self.EqDlg:
            prefs.set('eq-audio-lvls', self.audioEq.values())
            prefs.set('eq-video-lvls', self.videoEq.values())
        else:
            prefs.set('eq-audio-lvls', [0, 0, 0])
            prefs.set('eq-video-lvls', [0, 0, 0])

    def __newState(self, window, event):
        new_state = event.new_window_state
        if new_state != 0:
            self.EqDlg.hide()

    def onShowEqualizer(self, item):
        """ Shot the Equalizer dialog window """
        if not self.EqDlg:
            from gettext import gettext as _

            self.window = prefs.Window
            self.window.connect('window-state-event', self.__newState)

            from gui.window import GtkDialog
            self.EqDlg = GtkDialog(EQDLG.get_object('vbox1'), 128, -1)
            self.EqDlg.set_modal(True)
            self.EqDlg.set_opacity(0.95)
            self.EqDlg.set_resizable(False)
            self.EqDlg.set_title('')#_('Equalizer'))

            undo = EQDLG.get_object('btn-undo')
            undo.connect('button-press-event',
                lambda w,e: self.__resetEq())
            """
            def __save_eq():
                prefs.set('eq-audio-lvls', self.audioEq.values())
                prefs.set('eq-video-lvls', self.videoEq.values())
                self.EqDlg.emit('delete-event', None)
            save = EQDLG.get_object('btn-close')
            save.connect('button-press-event',
                lambda w,e: __save_eq())
            """
            close = EQDLG.get_object('btn-close')
            close.connect('button-press-event',
                lambda w,e: self.EqDlg.emit('delete-event', None))

            #!text to translate
            for (w,l) in (
                ('h',_('High')),
                ('m',_('Mid')),
                ('l',_('Low')),
                ):
                EQDLG.get_object(w).set_label(l)
            for (w,l) in (
                ('b',_('Brightness')),
                ('c',_('Contrast')),
                ('s',_('Saturation')),
                ):
                EQDLG.get_object(w).set_label(l)

            #!set default ranges
            self.__setEqRange()

        self.EqDlg.show()
        eq = self.EqDlg.get_allocation()
        (x,y), (w,h) = self.window.get_position(), self.window.get_size()
        self.EqDlg.move(x +w -eq.width -3, y +h -eq.height -3)
