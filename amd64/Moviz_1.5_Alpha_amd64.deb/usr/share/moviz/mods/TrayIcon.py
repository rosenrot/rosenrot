# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

import mods
from utils import prefs

MOD_INFO = (__name__, '', False, True)

class TrayIcon(mods.Module):

    icons = ('gtk-status-notplay','gtk-status',)
    playing = False

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:     self.onModLoaded,
            #ods.MSG_APP_QUIT:        self.onAppQuit,
            mods.MSG_MOD_LOADED:      self.onModLoaded,
            mods.MSG_MOD_UNLOADED:    self.onModUnloaded,
            mods.MSG_PAUSED:          self.onPaused,
            mods.MSG_STOPPED:         self.onStopped,
            mods.MSG_UNPAUSED:        self.onUnpaused,
            mods.MSG_NEW_TRACK:       self.onNewTrack,
                   }
        mods.Module.__init__(self, handlers)

    def __render(self, statusIcon, size):
        statusIcon.set_from_icon_name(self.icons[int(self.playing)])

    def __iconify(self):
        state = self.window.window.get_state()
        if state == gtk.gdk.WINDOW_STATE_ICONIFIED:
            self.window.present()#deiconify()
        else:
            if not self.window.has_toplevel_focus():
                self.window.present()
            else:
                self.window.hide()#iconify()

    def onAppStarted(self):
        pass
    def onAppQuit(self):
        pass

    def onModLoaded(self):
        self.statusIcon = gtk.StatusIcon()
        self.statusIcon.set_tooltip(prefs.appExec.title())
        self.statusIcon.connect('size-changed', self.__render)
        self.statusIcon.connect('popup-menu', self.onShowMenu)
        self.statusIcon.connect('activate', lambda w: self.__iconify())
        self.statusIcon.set_visible(True)
        self.window = prefs.Window
        self.window.set_skip_taskbar_hint(True) 

    def onModUnloaded(self):
        self.statusIcon.set_visible(False)
        self.window.set_skip_taskbar_hint(False) 

    def onNewTrack(self, track):
        self.playing = True
        self.statusIcon.set_from_icon_name(self.icons[1])
        self.statusIcon.set_tooltip(track.getTitle())

    def onPaused(self):
        self.playing = False
        self.statusIcon.set_from_icon_name(self.icons[0])

    def onUnpaused(self):
        self.playing = True
        self.statusIcon.set_from_icon_name(self.icons[1])

    def onStopped(self):
        self.playing = False
        self.statusIcon.set_from_icon_name(self.icons[0])
        self.statusIcon.set_tooltip(prefs.appExec.title())

    def onShowMenu(self, widget, button, time):
        menu = gtk.Menu()

        next = gtk.ImageMenuItem(gtk.STOCK_MEDIA_NEXT)
        next.connect('activate',
            lambda btn: mods.postMsg(mods.CMD_NEXT))
        menu.append(next)
        play = gtk.ImageMenuItem(gtk.STOCK_MEDIA_PLAY) \
            if not self.playing else gtk.ImageMenuItem(gtk.STOCK_MEDIA_PAUSE)
        play.connect('activate',
            lambda btn: mods.postMsg(mods.CMD_PLAY_PAUSE))
        menu.append(play)
        #prev = gtk.ImageMenuItem(gtk.STOCK_MEDIA_PREVIOUS)
        #prev.connect('activate',
        #    lambda btn: mods.postMsg(mods.CMD_PREVIOUS))
        #menu.append(prev)
        #about = gtk.ImageMenuItem(gtk.STOCK_ABOUT)
        #about.connect('activate', self.window.onAbout)
        #menu.append(about)

        menu.append(gtk.SeparatorMenuItem())
        quit = gtk.ImageMenuItem(gtk.STOCK_QUIT)
        quit.connect('activate',
            lambda btn: mods.postQuitMsg())
        menu.append(quit)

        menu.show_all()
        menu.popup(None, None, None, 0, time)
