# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME clean code
import gobject
import pprint

import mods, utils
from utils import gstbin, prefs

MOD_INFO = (__name__, '', True, False)

(
GST_PENDING, 
GST_NULL,
GST_READY,
GST_PAUSED,
GST_PLAYING,
) = range(5)

class Player(mods.ThreadedModule):

    _pos = 0
    _timer = None

    def __init__(self):
        self.playBin = gstbin.PlayBin2(self.__trackStarted, self.__trackEnded,
            prefs.getWidget('drawingarea1'))
        prefs.gstBin = self.playBin

        handlers = {
            mods.CMD_PLAY:          self.onPlay,
            mods.CMD_STOP:          self.onStop,
            mods.CMD_PLAY_PAUSE:    self.onTogglePause,
            mods.CMD_SEEK:          self.onSeek,
            mods.CMD_VOLUME:        self.onVolumeChanged,
                   }
        mods.ThreadedModule.__init__(self, handlers)

    def __startTimer(self):
        if not self._timer:
            self._timer = gobject.timeout_add(1000, self.__updateTimer)

    def __stopTimer(self):
        if self._timer:
            gobject.source_remove(self._timer)
        self._timer = None

    def __updateTimer(self):       
        pos = self.playBin.position()
        if pos != self._pos:
            self._pos = pos
            mods.postMsg(mods.MSG_NEW_POSITION, {'seconds': pos})
        return True

    def __trackEnded(self, error):
        if error and self._pos >= 0:
            self._pos = -1
            mods.postMsg(mods.MSG_ERROR)

        elif self._pos > 0:
            self._pos = 0
            mods.postMsg(mods.MSG_ENDED)

    def __trackStarted(self, msg):
        path = self.track.path
        tags = self.playBin.audioTags()
        tags['length'] = self.playBin.duration()
        #for k in sorted(tags.keys()):
        #   if 'bitrate' in k: tags['bitrate'] = tags[k]; break        
        tags['samplerate'] = self.playBin.sampleRate()
        tags.update(self.playBin.videoTags())

        if 'video-codec' in tags.keys():
            tags['video-size'] = '%dx%d' % self.playBin.videoSize()
        elif 'image' in tags.keys():
            from gui.dlg import saveImage
            data = tags['image']
            tags['image'] = saveImage(data[0] if type(data) == list else data,
                '%s/.image.jpg' % path[:path.rfind('/')] )
        #!local search ->
        #elif utils.isAudio(path):
        #    for (file, path) in utils.listDir(path[:path.rfind('/')], True):
        #        if file[file.rfind('.'):] in ('.jpg','.jpeg','.png',):
        #            tags['image'] = path
        #            break
        if path.startswith('dvd:'):
            tags['video-codec'] = u'DVD'
            tags['video-size'] = '16x9'
            #print msg, tags['title'].startswith('DVD Menu')
            #if tags['title'].startswith('DVD Menu'):
            tags['length'] = 0
            tags['title'] = self.track.tags['title']
            self.__stopTimer()
        elif path.startswith('cdda:'):
            pass
        elif not path.startswith('/'):
            try: tags['title'] = tags['organization']
            finally: tags['length'] = 0

        [tags.pop(k) for k in tags.keys() if not pprint.isreadable(tags[k])]
        print '<gst.Tags> %s' % str(tags)[1:-1]
        self.track.tags = tags

        if int(tags['length']) > 0:
            self.__startTimer()

        mods.postMsg(mods.MSG_NEW_TRACK, {'track': self.track})

    def onPlay(self, track):
        self._pos = 0
        self.track = track

        self.playBin.stop()
        self.playBin.setUri(track.path)
        self.playBin.play()
        #self.playBin.seek(1)!
        #if utils.isUnknow(track.path):
        #    prefs.Window.onBusy(True)

    def onStop(self):
        self._pos = 0
        self.__stopTimer()

        self.playBin.stop()
        mods.postMsg(mods.MSG_STOPPED)

    def onTogglePause(self):
        state = self.playBin.state()
        if state == GST_PAUSED:
            self.playBin.play()
            mods.postMsg(mods.MSG_UNPAUSED)

        elif state == GST_PLAYING:
            self.playBin.pause()
            mods.postMsg(mods.MSG_PAUSED)

    def onSeek(self, seconds):
        self.playBin.seek(int(seconds))

    def onVolumeChanged(self, level):
        self.playBin.volume(level)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
        #self.timeout = gobject.timeout_add(400, self._fadeStop, level)

    def _fadeVolume(self):
        if self._level == None:
            self.playBin.volume(self.level)
            self._fadeStop()

        elif self._level < self.level:
            self._level += float(self.level/3)
            if self._level > self.level:
                self._fadeStop(self.level)
            self.playBin.volume(self._level)
        else:
            self._level -= float(self.level/3)
            if self._level < 0:
                self._fadeStop(self.level)
            self.playBin.volume(self._level)

        return True

    def _fadeStop(self, level=0):
        gobject.source_remove(self.timeout)
        self.timeout = None

        self.playBin.volume(level)
