# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME shuffle func
import gtk
import random
from gettext import gettext as _

import gui, mods, utils
from gui import findAttr, sec2str
from gui.ext import ListView
from utils import prefs

MOD_INFO = (__name__, '', True, False)

(
    ROW_ICO,
    ROW_NUM,
    ROW_TIT,
    ROW_ART,
    ROW_ALB,
    ROW_LEN,
    ROW_EXT,
    ROW_TRK
) = range(8)

(
    COL_NUM,
    COL_TITLE,
    COL_ARTIST,
    COL_ALBUM,
    COL_LENGTH,
    COL_TYPE,
) = range(6)

PREFS_COLUMNS = {
    COL_NUM     : True,
    COL_TITLE   : True,
    COL_ARTIST  : False,
    COL_ALBUM   : False,
    COL_LENGTH  : True,
    COL_TYPE    : False,
    }

NONE  = prefs.pixEmpty()
ERROR = prefs.pixIcon(gtk.STOCK_CANCEL)
PLAY  = prefs.pixIcon(gtk.STOCK_MEDIA_PLAY)
PAUSE = prefs.pixIcon(gtk.STOCK_MEDIA_PAUSE)

class TrackList(mods.Module):

    trackIdx  = 0
    tracks    = []
    tracklist = []
    _randlist = []
    _oldList = None

    entry_text = None


    def __init__(self):
        handlers = {

            mods.MSG_APP_STARTED:       self.onAppStarted,
            mods.MSG_APP_QUIT:          self.onAppQuit,
            mods.MSG_PAUSED:        lambda: self.onPauseToggled(PAUSE),
            mods.MSG_UNPAUSED:      lambda: self.onPauseToggled(PLAY),
            mods.MSG_ENDED:             self.onTrackEnded,
            mods.MSG_ERROR:         lambda: self.onTrackEnded(error=True),
            mods.MSG_STOPPED:           self.onStopped,
            mods.MSG_NEW_TRACK:         self.onNewTrack,

            mods.CMD_PLAY_PAUSE:        self.onPlay,
            mods.CMD_NEXT:              self.jumpToNext,
            mods.CMD_PREVIOUS:          self.jumpToPrevious,
            mods.CMD_TRACKS_ADD:     self.insert,
            mods.CMD_TRACKS_SET:     self.replace,
            mods.CMD_TRACKS_CLR: lambda: self.replace(None),
            mods.CMD_TRACKS_PLAY:    self.jumpTo,
            mods.CMD_TRACKS_DEL:     self.remove,

                   }
        mods.Module.__init__(self, handlers)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _



    def onAppStarted(self):
        """ The application has been started """
        self.window = prefs.Window
        widget = prefs.getExtWidget

        self.addListView()
        self.scrollwin = widget('scrolled1')
        self.scrollwin.add(self.trkList)

        self.entry = widget('entry1')
        self.entry.connect('activate', self.onEntryActivate)
        self.entry.connect('icon-press', self.onEntryIconPressed)
        self.entry.connect('focus-out-event', lambda w,e: w.set_visible(
            w.get_icon_stock(1) == gtk.STOCK_REVERT_TO_SAVED))

        self.notebook = widget('notebook1')
        self.notebook.connect('switch-page', lambda w,pw,pn:
            self.__revert(self.entry) if pn != 0 else None)


        self.tab = widget('btn-trk')
        self.tab.connect('clicked', lambda w: self.notebook.set_current_page(0))


        self.shuffle = not prefs.get('tracklist-shuffle', False)
        self.repeat = prefs.get('tracklist-repeat', False)
        btn_shuffle = prefs.getWidget('btn-shuffle')#FIXME
        #btn_shuffle.connect('clicked', lambda w:prefs.Window.dlgTrackList.show())  #self.onSetShuffle)
        #btn_shuffle.emit('clicked')



    def onAppQuit(self):
        """ The application is about to terminate """
        prefs.set('tracklist-shuffle', self.shuffle)
        #prefs.set('tracklist-repeat', self.repeat.get_active())
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def addListView(self):
        """ Set up the columns' properties """
        from gobject import TYPE_STRING, TYPE_INT, TYPE_PYOBJECT

        txtLRdr   = gtk.CellRendererText()
        txtRRdr   = gtk.CellRendererText()
        pixbufRdr = gtk.CellRendererPixbuf()

        txtLRdr.set_property('width-chars', 64)
        txtLRdr.set_property('ellipsize', 'end')
        txtRRdr.set_property('width-chars', 10)
        txtRRdr.set_property('xalign', 1.0)

        visible = prefs.get('tracklist-columns', PREFS_COLUMNS)
        columns = (
            ('#', [(pixbufRdr, gtk.gdk.Pixbuf), (txtLRdr, TYPE_INT)], (ROW_NUM,),
            False, visible[COL_NUM]),            
            (_('Title'), [(txtLRdr, TYPE_STRING)], (ROW_TIT,),
            True,  visible[COL_TITLE]),
            (_('Artist'), [(txtLRdr, TYPE_STRING)], (ROW_ART,),
            True,  visible[COL_ARTIST]),
            (_('Album'), [(txtLRdr, TYPE_STRING)], (ROW_ALB,),
            True,  visible[COL_ALBUM]),
            (_('Length'), [(txtRRdr, TYPE_INT)], (ROW_LEN,),
            False, visible[COL_LENGTH]),
            (_('Type'), [(txtRRdr, TYPE_STRING)], (ROW_EXT,),
            False, visible[COL_TYPE]),
            (None, [(None, TYPE_PYOBJECT)], (None,),
            False, False)
            )

        self.trkList = ListView(columns, dndTargets=prefs.dndTarget,
            showHide=True, sortable=True, markup=False)
        self.trkList.enableDNDReordering()

        self.trkList.get_column(0).set_max_width(20)
        self.trkList.get_column(1).set_max_width(100)
        self.trkList.get_column(2).set_max_width(100)
        self.trkList.get_column(3).set_max_width(100)
        self.trkList.get_column(4).set_cell_data_func(txtRRdr, self.__fmtLength)
        self.trkList.get_column(4).set_max_width(60)
        self.trkList.get_column(5).set_max_width(60)

        self.trkList.connect('extlistview-dnd',
            self.onDND)
        self.trkList.connect('key-press-event',
            self.onKeyPressed)
        self.trkList.connect('extlistview-modified',
            self.onListModified)
        self.trkList.connect('extlistview-button-pressed',
            self.onButtonPressed)
        self.trkList.connect('extlistview-selection-changed',
            self.onSelectionChanged)
        self.trkList.connect('extlistview-column-visibility-changed',
            self.onColumnChanged)
        #self.trkList.connect("start-interactive-search",...)

    def onColumnChanged(self, list, colTitle, visible):
        """ A column has been shown/hidden """
        if colTitle == '#':            colId = COL_NUM
        elif colTitle == _('Title'):   colId = COL_TITLE
        elif colTitle == _('Artist'):  colId = COL_ARTIST
        elif colTitle == _('Album'):   colId = COL_ALBUM
        elif colTitle == _('Length'):  colId = COL_LENGTH
        elif colTitle == _('Type'):    colId = COL_TYPE

        visibility = prefs.get('tracklist-columns', PREFS_COLUMNS)
        visibility[colId] = visible

        prefs.set('tracklist-columns', visibility)

    def __fmtLength(self, col, cll, mdl, it):
        cll.set_property('text', sec2str(mdl.get_value(it, ROW_LEN)))

    def __nextTrackIdx(self):
        if self.trkList.hasMark():
            if self.trkList.getMark() < len(self.trkList) -1:
                return self.trkList.getMark() +1
        return -1

    def __previousTrackIdx(self):
        if self.trkList.hasMark():
            if self.shuffle:
                return (len(self._randlist) > 1) -1
            elif self.trkList.getMark() > 0:
                return self.trkList.getMark()-1
        return -1

    def __hasNextTrack(self):
        return self.__nextTrackIdx() != -1

    def __hasPreviousTrack(self):
        return self.__previousTrackIdx() != -1
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def insert(self, tracks, playNow=False, position=None):
        """ Insert the tracks in the tracklist, append if position is None """
        rows = [[NONE,
            track.ppos,
            track.getFileName(),
            '',
            '',
            track.getLength(),
            track.getType(),
            track] for track in tracks]

        if len(rows) != 0:
            self._oldList = [row[ROW_TRK] for row in self.trkList]
            self.trkList.insertRows(rows,
                len(self._oldList) if position is None else position)

            if position != None:
                self.trkList.scroll_to_cell(position)

            if playNow:
                if position: self.jumpTo(position)
                else: self.jumpTo(len(self._oldList))

    def replace(self, tracks, playNow=True):
        """ Replace the tracklist, clear it if tracks is None """
        oldList = [row[ROW_TRK] for row in self.trkList]
        self.trkList.clear()

        if tracks:
            self.insert(tracks, playNow)
        elif playNow:
            mods.postMsg(mods.CMD_STOP)

        self._oldList = oldList
        self._randlist = []

    def remove(self, idx=None):
        """ Remove the selected tracks """
        self.trackIdx = self.trkList.getMark()    
        self._oldList = [row[ROW_TRK] for row in self.trkList]

        if idx:
            self.trkList.removeRow((idx, ))
        else:
            self.trkList.removeSelectedRows()
        self.trkList.unselectAll()

        if self.trackIdx < 0 or self.trackIdx >= self.trkList.getCount():
            return
        if not self.trkList.hasMark():#FIXME
            #self.trkList.setMark(trackIdx -1)
            self.jumpToNext()

    def crop(self):
        """ Remove the unselected tracks """
        self._oldList = [row[ROW_TRK] for row in self.trkList]
        self.trackIdx = self.trkList.getMark()

        self.trkList.cropSelectedRows()
        self.trkList.unselectAll()

    def revert(self):
        """ Back to the previous tracklist """
        if not self._oldList:
            return

        if self.trkList.hasMark():
            idx = self.trkList.getRow(self.trkList.getMark())[ROW_TRK]
        else:
            idx = None

        self.replace(self._oldList, False)
        self._oldList = None

        if idx:
            for i,v in enumerate(
                [row[ROW_TRK] for row in self.trkList.iterAllRows()]):
                if v == idx:
                    self.trackIdx = i
                    break

        self.jumpTo(self.trackIdx, False)

#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onListModified(self, trklist):
        """ Emitted when the list is changed """
        for position, row in enumerate(trklist):
            row[ROW_TRK].ppos = position +1
        #if len(trklist) != len(self.tracks):
        self.tracks = [row[ROW_TRK] for row in trklist]
        mods.postMsg(mods.MSG_NEW_TRACKS, {'tracks': self.tracks})

        if len(trklist) != 0 and self.trkList.hasMark():
            mods.postMsg(mods.MSG_TRACK_MOVED, {
                'hasPrevious': self.__hasPreviousTrack(),
                'hasNext':  self.__hasNextTrack()})

    def onSelectionChanged(self, list, selectedRows):
        """ Emitted when the selection is changed """
        mods.postMsg(mods.MSG_TRACK_SELECTED,
            {'tracks': [row[ROW_TRK] for row in selectedRows]})

    def onSetShuffle(self, btn):#FIXME
        """ Emitted when the shuffle button is clicked """
        self.shuffle = not self.shuffle
        btn.set_image(prefs.pixName('stock-shuffle') if self.shuffle else
            prefs.pixName('stock-shuffle-off'))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def jumpTo(self, trackIdx, playNow=True):#FIXME
        """ Jump to the track located at the given index """
        if trackIdx < 0 or trackIdx >= self.trkList.getCount():
            return

        if self.trkList.hasMark() and self.trkList.getItem(
            self.trkList.getMark(), ROW_ICO) != ERROR:
                self.trkList.setItem(self.trkList.getMark(), ROW_ICO, NONE)

        self.trkList.setMark(trackIdx)
        self.trkList.scroll_to_cell(trackIdx)
        self.trkList.setItem(trackIdx, ROW_ICO, PLAY)
        self.trkList.unselectAll()
        self.trkList.selectRow(trackIdx)
    
        self.track = self.trkList.getItem(trackIdx, ROW_TRK)

        if playNow:
            mods.postMsg(mods.CMD_PLAY, {'track': self.track})
        mods.postMsg(mods.MSG_TRACK_MOVED, {
            'hasPrevious': self.__hasPreviousTrack(),
            'hasNext': self.__hasNextTrack()})

    def jumpToNext(self):
        """ Jump to the next track, or random if shuffle is enabled """
        if self.shuffle:
            self.jumpToRandom()
        else: 
            self.jumpTo(self.__nextTrackIdx())

    def jumpToPrevious(self):
        """ Jump to the previous track, or previous random """
        if self.shuffle:
            try:
                self._randlist.remove(self._randlist[-1])
                self.jumpTo(self._randlist[-1])
            except:               
                self._randlist = []
        else: 
            self.jumpTo(self.__previousTrackIdx())

    def jumpToRandom(self):
        """ Jump to a random track number """
        if not self._randlist:
            self._randlist.append(self.trkList.getMark())
        try:
            where = random.choice([ x for x in range(len(self.trkList))
                if x not in self._randlist])

            self._randlist.append(where)
            self.jumpTo(where)
        except:
            self._randlist = []

            mods.postMsg(mods.CMD_STOP)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onNewTrack(self, track):
        """ A new track is being played """
        rowNum = track.ppos -1
        if rowNum >= 0:
            self.trkList.setItem(rowNum, ROW_TIT, track.getTitle())
            self.trkList.setItem(rowNum, ROW_ART, track.getArtist())
            self.trkList.setItem(rowNum, ROW_ALB, track.getAlbum())
            self.trkList.setItem(rowNum, ROW_LEN, track.getLength())

    def onTrackEnded(self, error=False):
        """ The current track has ended, jump to the next one or stop """
        trackIdx = self.trkList.getMark()
        if trackIdx is None:
            mods.postMsg(mods.CMD_STOP); return
        elif error:
            self.trkList.setItem(trackIdx, ROW_ICO, ERROR)

        if self.shuffle:
            self.jumpToRandom()
        elif trackIdx == len(self.trkList)-1:
            #if self.repeat:
            #    self.jumpTo(0)
            #else:
            mods.postMsg(mods.CMD_STOP)
        else:
            self.jumpToNext()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onPlay(self):
        """ Start playing if not already playing """
        if len(self.trkList) != 0 and not self.trkList.hasMark():
            if self.trkList.getSelectedRowsCount() == 0: self.jumpTo(0)
            else: self.jumpTo(self.trkList.getFirstSelectedRowIndex())

    def onPauseToggled(self, icon):
        """ Switch between pause and unpause """
        if self.trkList.hasMark():
            self.trkList.setItem(self.trkList.getMark(), ROW_ICO, icon)

    def onStopped(self):
        """ Playback has been stopped """
        if self.trkList.hasMark():
            currTrack = self.trkList.getMark()

            if self.trkList.getItem(currTrack, ROW_ICO) != ERROR:
                self.trkList.setItem(currTrack, ROW_ICO, NONE)

            self.trkList.clearMark()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onButtonPressed(self, list, event, path):
        """ Emitted on click of an item """
        if event.button == 1 and event.type == gtk.gdk._2BUTTON_PRESS and path:
            self.jumpTo(path[0])
        elif event.button == 3:
            self.onPopupMenu(list, path, event.button, event.time)

    def onDND(self, list, context, x, y, dragData, dndId, time):
        """ Emitted on drag'n'drop """
        tracks = utils.getTracksFromDnd(dragData, dndId)
        if not tracks:
            context.drop_finish(True, time)
            return

        dropInfo = list.get_dest_row_at_pos(x, y)
        if not dropInfo:
            self.insert(tracks, False)
        elif dropInfo[1] == gtk.TREE_VIEW_DROP_AFTER:
            self.insert(tracks, False, dropInfo[0][0] + 1)
        else:
            self.insert(tracks, False, dropInfo[0][0])

        context.drop_finish(True, time)

    def onEntryActivate(self, entry):
        """ Emitted on new search action """
        if self.notebook.get_current_page() != 0:
            return
        text = entry.get_text().lower()
        if not text:
            self.__revert(entry)
            return
        self.trkList.unselectAll()
        for n,r in enumerate(self.trkList):
            if findAttr(text, r[ROW_TIT].lower()):
                self.trkList.selectRow(n)
            elif findAttr(text, r[ROW_ART].lower(), False):
                self.trkList.selectRow(n)
        if self.trkList.getSelectedRowsCount() != 0:
            self.crop()
            entry.set_icon_from_stock(1, gtk.STOCK_REVERT_TO_SAVED)
        entry.set_text('')

    def onEntryIconPressed(self, entry, icon, event):
        """ Emitted when an icon of the entry is pressed """
        #if icon == gtk.ENTRY_ICON_PRIMARY:
        #    self.notebook.set_current_page(self.notebook.get_current_page() -1)
        if self.notebook.get_current_page() != 0:
            return
        elif icon == gtk.ENTRY_ICON_SECONDARY:
            self.__revert(entry)

    def __revert(self, entry):
        if entry.get_icon_stock(1) == gtk.STOCK_REVERT_TO_SAVED:
            self.revert()
            entry.set_icon_from_stock(1, None)            
        entry.hide()

    def onOpenPath(self, path):
        """ Open the directory of the selected track """
        import subprocess

        subprocess.Popen(['xdg-open',
            self.trkList.getRow(path)[ROW_TRK].getDirName()])

    def onOpenDir(self, add=False):
        """ Open the directory of the selected track """
        from gui.dlg import openFile

        dir = openFile(None, add)
        if dir: self.insert(utils.getTracks([dir,]), not add, 0)

    def onOpenLocation(self):
        """ Open a location from the pathname in the clipboard """
        try: uri = gtk.clipboard_get().wait_for_text()
        except: uri = ''
        if not '/' in uri: return
        tracks = [utils.getTrack(uri),] if utils.isUnknow(uri) \
            else utils.getTracks([uri,])
        if tracks:
            mods.postMsg(mods.CMD_TRACKS_SET, {'tracks': tracks, 'playNow': True})

    def onSaveList(self, path):        
        from gui.dlg import saveFile

        path = saveFile(self.tracks[0].getDirName() +'/playlist.m3u')
        if path: utils.savePlaylist([t.path for t in self.tracks], path)

    def onPopupMenu(self, list, path, button, time):
        """ Emitted on the right-click """
        menu = gtk.Menu()

        xdgopen = gtk.ImageMenuItem(_('Open location'))
        xdgopen.set_image(prefs.pixStock(gtk.STOCK_OPEN))
        xdgopen.set_sensitive(path != None)
        xdgopen.connect('activate', lambda w: self.onOpenPath(path))
        menu.append(xdgopen)

        menu.append(gtk.SeparatorMenuItem())
        paste = gtk.ImageMenuItem(gtk.STOCK_PASTE)
        paste.connect('activate', lambda w: self.onOpenLocation())
        menu.append(paste)
        crop = gtk.ImageMenuItem(gtk.STOCK_CUT)
        crop.set_sensitive(path != None)
        crop.connect('activate', lambda w: self.crop())
        menu.append(crop)
        remove = gtk.ImageMenuItem(gtk.STOCK_REMOVE)
        remove.set_sensitive(path != None)
        remove.connect('activate', lambda w: self.remove())
        menu.append(remove)

        menu.append(gtk.SeparatorMenuItem())
        clear = gtk.ImageMenuItem(gtk.STOCK_CLEAR)
        clear.set_sensitive(len(list) != 0)
        clear.connect('activate', lambda w:
            mods.postMsg(mods.CMD_TRACKS_CLR))
        menu.append(clear)
        revert = gtk.ImageMenuItem(gtk.STOCK_REVERT_TO_SAVED)
        revert.set_sensitive(self._oldList != None)
        revert.connect('activate', lambda w: self.revert())
        menu.append(revert)

        menu.append(gtk.SeparatorMenuItem())
        save = gtk.ImageMenuItem(gtk.STOCK_SAVE_AS)
        save.set_sensitive(len(list) != 0)
        save.connect('activate', lambda w: self.onSaveList(path))
        menu.append(save)

        menu.show_all()
        menu.popup(None, None, None, button, time)

    def onKeyPressed(self, list, event):
        """ Emitted on key press """
        key = gtk.gdk.keyval_name(event.keyval)
        if len(key) == 1 and key.isalnum():
            self.entry.set_no_show_all(False)
            self.entry.set_text(key)
            self.entry.show()
            self.entry.grab_focus()
            self.entry.do_move_cursor(self.entry, 1, 1, False)
        elif key == 'Escape':
            mods.postMsg(mods.CMD_STOP)
        #print key
