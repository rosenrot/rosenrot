# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME
import dbus, dbus.service
from time import time

import mods, utils
from utils import prefs

MOD_INFO = (__name__, '', True, False)

#!d-bus service
DBUS_NAME = 'org.mpris.%s' % prefs.appExec
DBUS_INTERFACE = 'org.freedesktop.MediaPlayer'

#!unique id for not interfere with multiple instances
APP_UID = '%s.%s' % (prefs.appExec, time())

#!caps constants
CAPS_CAN_GO_NEXT          =  1
CAPS_CAN_GO_PREV          =  2
CAPS_CAN_PAUSE            =  4
CAPS_CAN_PLAY             =  8
CAPS_CAN_SEEK             = 16
CAPS_CAN_HAS_METADATA     = 32
CAPS_CAN_HAS_TRACKS       = 64

class DBus(mods.ThreadedModule):

    paused = False
    position = 0
    track = None
    tracklist = []

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:   self.onAppStarted,
            mods.MSG_APP_QUIT:      self.onAppQuit,
            mods.MSG_NEW_TRACK:     self.onNewTrack,
            mods.MSG_NEW_POSITION:  self.onNewTrackPosition,
            mods.MSG_PAUSED:        self.onPaused,
            mods.MSG_UNPAUSED:      self.onUnpaused,
            mods.MSG_STOPPED:       self.onStopped,
            #ods.MSG_MOVED:         self.onTrackMoved,
                   }
        mods.ThreadedModule.__init__(self, handlers)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onAppStarted(self):
        """ Initialization """
        import dbus.mainloop.glib
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)

        self.sessionBus = dbus.SessionBus()
        self.busName = dbus.service.BusName(DBUS_NAME, bus=self.sessionBus)
        self.busObjectRoot = DBusObjectRoot(self.busName, self)
        self.busObjectPlayer = DBusObjectPlayer(self.busName, self)
        self.busObjectTracklist = DBusObjectTracklist(self.busName, self)
        try:
            service = self.sessionBus.get_object(
                'org.gnome.SettingsDaemon', '/org/gnome/SettingsDaemon/MediaKeys')
            self.dbusInterface = dbus.Interface(service,
                'org.gnome.SettingsDaemon.MediaKeys')
            self.dbusInterface.GrabMediaPlayerKeys(APP_UID, time())
            self.dbusInterface.connect_to_signal('MediaPlayerKeyPressed',
                self.onMediaKey)
        except Exception, err:
            self.dbusInterface = None
            import traceback
            print traceback.format_exc()

    def onAppQuit(self):
        """ The application is about to terminate """
        if self.dbusInterface:
            self.dbusInterface.ReleaseMediaPlayerKeys(APP_UID)

    def onMediaKey(self, appName, action):
        """ A media key has been pressed """
        if action in ('Play','Pause'):
            mods.postMsg(mods.CMD_PLAY_PAUSE)
        elif action == 'Next':
            mods.postMsg(mods.CMD_NEXT)
        elif action == 'Previous':
            mods.postMsg(mods.CMD_PREVIOUS)
        elif action == 'Stop':
            mods.postMsg(mods.CMD_STOP)

    def onNewTrack(self, track):
        """ A new track is being played """
        self.paused = False
        self.track = track

        self.busObjectPlayer.CapsChange(self.getMPRISCaps())
        self.busObjectPlayer.TrackChange(track.getMPRISMetadata())
        self.busObjectPlayer.StatusChange(self.getMPRISStatus())

    def onNewTrackPosition(self, seconds):
        """ New position in the current track """
        self.position = seconds

    def onPaused(self):
        """ The playback has been paused """
        self.paused = True

        self.busObjectPlayer.StatusChange(self.getMPRISStatus())

    def onUnpaused(self):
        """ The playback has been unpaused """
        self.paused = False

        self.busObjectPlayer.StatusChange(self.getMPRISStatus())

    def onStopped(self):
        """ Playback is stopped """
        self.paused = False
        self.position = 0
        self.track = None

        self.busObjectPlayer.CapsChange(self.getMPRISCaps())
        self.busObjectPlayer.StatusChange(self.getMPRISStatus())

    def onTrackMoved(self, hasPrevious, hasNext):
        """ The playlist position of track is changed """
        self.hasPrevious = hasPrevious
        self.hasNext = hasNext
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def getMPRISCaps(self):
        """ Return an integer sticking to the MPRIS caps definition """
        caps = CAPS_CAN_HAS_TRACKS
        if len(self.tracklist) != 0:
            caps |= CAPS_CAN_PLAY
        if self.track:
            caps |= CAPS_CAN_PAUSE
            caps |= CAPS_CAN_SEEK
            caps |= CAPS_CAN_HAS_METADATA
            #if self.hasNext: caps |= CAPS_CAN_GO_NEXT
            #if self.hasPrevious: caps |= CAPS_CAN_GO_PREV
        return caps

    def getMPRISStatus(self):
        """ Return a tuple sticking to the MPRIS status definition """
        if self.track == None:
            return (2, 0, 0, 0)
        elif self.paused:
            return (1, 0, 0, 0)
        else:
            return (0, 0, 0, 0)        
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class DBusObjectRoot(dbus.service.Object):

    def __init__(self, busName, module):
        dbus.service.Object.__init__(self, busName, '/')

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='s')
    def Identity(self):
        """ Returns a string containing the player identification """
        return '%s %s' % (prefs.appName, prefs.appVersion)

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Quit(self):
        """ Quit the player """
        mods.postQuitMsg()

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='(qq)')
    def MprisVersion(self):
        """ Returns a struct that represents the version of the MPRIS specs """
        return (1, 0)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class DBusObjectTracklist(dbus.service.Object):

    def __init__(self, busName, module):
        self.module = module
        dbus.service.Object.__init__(self, busName, '/TrackList')

    @dbus.service.method(DBUS_INTERFACE, in_signature='asb', out_signature='')
    def AddTracks(self, uris, playNow):
        """ Appends multiple URIs to the tracklist """
        mods.postMsg(mods.CMD_TRACKS_ADD, {
            'tracks': utils.getTracks(uris), 'playNow': playNow})

    @dbus.service.method(DBUS_INTERFACE, in_signature='asb', out_signature='')
    def SetTracks(self, uris, playNow):
        """ Replace the tracklist by the given URIs """
        mods.postMsg(mods.CMD_TRACKS_SET, {
            'tracks': [utils.getTrack(uris[0]),] if utils.isUnknow(uris[0]) \
                else utils.getTracks(uris),
            'playNow': playNow})
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class DBusObjectPlayer(dbus.service.Object):

    def __init__(self, busName, module):
        self.module = module
        dbus.service.Object.__init__(self, busName, '/Player')

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='(iiii)')
    def GetStatus(self):
        """ Return the status of player as a struct of 4 ints """
        return self.module.getMPRISStatus()

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='a{sv}')
    def GetMetadata(self):
        """ Gives all meta data available for the currently played element """
        if self.module.track is None:
            return {}
        else:
            return self.module.track.getMPRISMetadata()

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='i')
    def GetCaps(self):
        """ Return the player's current capabilities """
        return self.module.getMPRISCaps()

    @dbus.service.signal(DBUS_INTERFACE, signature='i')
    def CapsChange(self, caps):
        """ Signal is emitted when the player changes capabilities """
        pass

    @dbus.service.signal(DBUS_INTERFACE, signature='(iiii)')
    def StatusChange(self, status):
        """ Signal is emitted when the status of the player change """
        pass

    @dbus.service.signal(DBUS_INTERFACE, signature='a{sv}')
    def TrackChange(self, metadata):
        """ Signal is emitted when the player plays another track """
        pass

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='i')
    def PositionGet(self):
        """ Return the position, [0;<track_length>] in ms """
        return self.module.position *1000

    @dbus.service.method(DBUS_INTERFACE, in_signature='i', out_signature='')
    def PositionSet(self, position):#FIXME
        """ Set the position, [0;<track_length>] in ms """
        pass #mods.postMsg(mods.CMD_SEEK, {'seconds': position /1000})

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Play(self):
        """ If playing, rewind to the beginning, else start playing """
        mods.postMsg(mods.CMD_PLAY_PAUSE)

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Pause(self):
        """ If playing, pause, else unpause """
        mods.postMsg(mods.CMD_PLAY_PAUSE)

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Prev(self):
        """ Go to the previous """
        mods.postMsg(mods.CMD_PREVIOUS)

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Next(self):
        """ Go to the next """
        mods.postMsg(mods.CMD_NEXT)

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Stop(self):
        """ Stop playing """
        mods.postMsg(mods.CMD_STOP)

    @dbus.service.method(DBUS_INTERFACE, in_signature='', out_signature='')
    def Volume(self, volume):
        """ Set the volume (argument must be in [0;100]) """
        mods.postMsg(mods.CMD_VOLUME, {'level': volume})
