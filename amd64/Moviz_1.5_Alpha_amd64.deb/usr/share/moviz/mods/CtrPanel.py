# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import mods
from gui import sec2str, sizeInfo
from utils import prefs

MOD_INFO = (__name__, '', True, False)

class CtrPanel(mods.Module):

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:     self.onAppStarted,
            mods.MSG_APP_QUIT:        self.onAppQuit,
            mods.MSG_PAUSED:          self.onPaused,
            mods.MSG_UNPAUSED:        self.onUnpaused,
            mods.MSG_STOPPED:         self.onStopped,
            mods.MSG_NEW_TRACK:       self.onNewTrack,
            mods.MSG_TRACK_MOVED:     self.onTrackMoved,
            mods.MSG_NEW_POSITION:    self.onNewTrackPosition,
                   }
        mods.Module.__init__(self, handlers)

    def onAppStarted(self):
        """ The application is started """
        self.window  = prefs.Window

        #self.lblInfo = prefs.getWidget('lbl-info')
        #self.lblTime = prefs.getWidget('lbl-time')

        self.btnPlay = prefs.getWidget('btn-play')
        self.btnNext = prefs.getWidget('btn-next')
        self.btnPrev = prefs.getWidget('btn-prev')
        #elf.btnStop = prefs.getWidget('btn-stop')

        self.pixPlay, self.pixPause = (
            prefs.pixName('media-play'),
            prefs.pixName('media-pause'),)

        self.btnPlay.connect('clicked',
            lambda widget: mods.postMsg(mods.CMD_PLAY_PAUSE))
        self.btnNext.connect('clicked',
            lambda widget: mods.postMsg(mods.CMD_NEXT))
        self.btnPrev.connect('clicked',
            lambda widget: mods.postMsg(mods.CMD_PREVIOUS))
        #self.btnStop.connect('clicked',
        #   lambda widget: mods.postMsg(mods.CMD_STOP))

        self.sclDragged = False
        self.sclSeek = prefs.getWidget('scl-seek')
        self.sclSeek.set_range(0, 100)
        self.sclSeek.set_increments(1, 10)

        self.sclSeek.connect('button-press-event', self.onSeekPressed)
        self.sclSeek.connect('button-release-event', self.onSeekReleased)
        self.sclSeek.connect('change-value', self.onSeekChanging)
        self.sclSeek.connect('value-changed', self.onSeekChanged)

        self.btnVolume = prefs.getWidget('btn-volume')
        self.btnVolume.set_value(prefs.get('player-volume', 1.0))
        self.btnVolume.connect('value-changed', self.onVolumeChanged)

    def onAppQuit(self):
        """ The application is about to quit """
        prefs.set('player-volume', self.btnVolume.get_value())
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onNewTrack(self, track):
        """ A new track is being played """
        artist, title = track.getArtist(), track.getTitle()
        _name = '%s - %s' % (artist, title) if artist != '~' else title
        tags = track.tags
        _tags = (tags['video-codec'].replace('/ ', ''), tags['video-size'],) \
         if 'video-codec' in tags.keys() else (track.getType().upper(),)
        _tags += ('%skbps' % track.getBitrate(), sizeInfo(track.path))
        self.title = '%s ! %s' % (_name, ' '.join(_tags))
        self.length = track.getLength()

        self.window.set_title(self.title)

        self.btnPlay.set_sensitive(True)
        self.btnPlay.set_image(self.pixPause)

        self.sclSeek.handler_block_by_func(self.onSeekChanged)
        self.sclSeek.set_range(0, self.length if self.length else 1)
        self.sclSeek.set_value(0)
        self.sclSeek.set_sensitive(self.length > 0)
        self.sclSeek.handler_unblock_by_func(self.onSeekChanged)

    def onNewTrackPosition(self, seconds):        
        if self.sclDragged: return
        # make sure handler will not be called
        self.sclSeek.handler_block_by_func(self.onSeekChanged)
        self.sclSeek.set_value(seconds)
        self.sclSeek.handler_unblock_by_func(self.onSeekChanged)

        #self.lblTime.set_label('%s | %s' % (
        #    sec2str(seconds), sec2str(self.length)))
        #self.seconds = seconds

    def onTrackMoved(self, hasPrevious, hasNext):
        self.btnNext.set_sensitive(hasNext)
        self.btnPrev.set_sensitive(hasPrevious)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onPaused(self):
        self.btnPlay.set_image(self.pixPlay)
        #self.lblTime.set_label('%s | %s' % (
        #    sec2str(self.seconds), sec2str(self.length) ) )

    def onUnpaused(self):
        self.btnPlay.set_image(self.pixPause)
        #self.lblTime.set_label('')

    def onStopped(self):
        self.window.set_title(prefs.appExec.title())

        #self.lblInfo.set_label('')
        #self.lblTime.set_label('')

        self.btnPlay.set_image(self.pixPlay)
        self.btnNext.set_sensitive(False)
        self.btnPrev.set_sensitive(False)

        self.sclSeek.handler_block_by_func(self.onSeekChanged)
        self.sclSeek.set_sensitive(False)
        self.sclSeek.set_value(0)
        self.sclSeek.handler_unblock_by_func(self.onSeekChanged)

    def onSeekPressed(self, scale, event):
        self.sclDragged = True
        if event.button == 1:
            event.button = 2
            scale.emit('button-press-event', event)

    def onSeekReleased(self, scale, event):
        self.sclDragged = False

        if event.button == 1:
            event.button = 2
            scale.emit('button-release-event', event)

        self.window.set_title(self.title)

    def onSeekChanging(self, scale, scroll, seconds):
        if seconds > self.length:
            seconds = self.length


        self.window.set_title('%s ! %s' % (
            sec2str(seconds), sec2str(self.length)))

    def onSeekChanged(self, scale):
        mods.postMsg(mods.CMD_SEEK, {'seconds': scale.get_value()})
        #self.btnPlay.grab_focus()

    def onVolumeChanged(self, button, level):
        mods.postMsg(mods.CMD_VOLUME, {'level': round(level, 1)})
        #self.btnPlay.grab_focus()
