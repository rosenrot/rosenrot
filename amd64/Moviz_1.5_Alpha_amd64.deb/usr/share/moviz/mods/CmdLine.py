# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import mods, utils
from utils import prefs
from utils.prefs import pickleLoad, pickleSave

MOD_INFO = (__name__, '', True, False)

class CmdLine(mods.ThreadedModule):

    seconds = 0
    track   = None
    tracks  = []

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:       self.onAppStarted,
            mods.MSG_APP_QUIT:          self.onAppQuit,
            mods.MSG_NEW_TRACK:         self.onNewTrack,
            mods.MSG_NEW_TRACKS:        self.onNewTracklist,
            mods.MSG_NEW_POSITION:      self.onNewTrackPosition,
            mods.MSG_STOPPED:           self.onStopped,
                   }
        mods.ThreadedModule.__init__(self, handlers)

    def onAppStarted(self):
        opts, args = prefs.cmdLine
        if args:
            tracks = [utils.getTrack(args[0]),] if utils.isUnknow(args[0]) \
                else utils.getTracks(args)
            mods.postMsg(mods.CMD_TRACKS_SET, {
                'tracks': tracks, 'playNow': True})
        elif not opts.new:
            try:
                tracks = pickleLoad(prefs.filePlaylist)
                if not tracks: raise
            except:
                prefs.Window.Ext.present()
                return
            mods.postMsg(mods.CMD_TRACKS_SET, {
                'tracks': tracks, 'playNow': False})
            #if opts.tray: return
            track = prefs.get('playing-track', None)
            if track != None and not track[0] > len(tracks) and track[1] > 1:
                mods.postMsg(mods.CMD_TRACKS_PLAY,
                    {'trackIdx': track[0] -1, 'playNow': True})
                mods.postMsg(mods.CMD_SEEK, {'seconds': track[1]})
            else:
                prefs.Window.Ext.present()

    def onAppQuit(self):
        opts, args = prefs.cmdLine
        if not opts.new:
            if self.track: prefs.set('playing-track', (
                self.track.ppos, self.seconds))
            pickleSave(prefs.filePlaylist, self.tracks)
        utils.setTracks()

    def onNewTrack(self, track):
        if track.path.startswith('/'):
            self.track = track
            #prefs.set('player-track', self.track)
            utils.setTracks(track)

    def onNewTracklist(self, tracks):
        self.tracks = tracks            

    def onNewTrackPosition(self, seconds):
        self.seconds = seconds

    def onStopped(self):
        self.seconds = 0
