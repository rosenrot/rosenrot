# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
import os.path
import urllib
import webkit#gtkmozembed

from mods import swf, size2str

class GtkWindow(gtk.Window):

    def __init__(self, file):
        gtk.Window.__init__(self)

        header = swf.parse(file)#{'width': 640, 'height': 480, 'size': 0,}
        iw,ih = header['width'],header['height']
        sw,sh = gtk.gdk.screen_width() *0.85, gtk.gdk.screen_height() *0.85
        if iw > sw: ow,oh = sw, ih*sw/iw
        else: ow,oh = iw,ih
        if oh > sh: ow,oh = iw*sh/ih, sh
        elif iw < 480: ow,oh = 480, 480*ih/iw

        web = webkit.WebView()#self.mozBox = gtkmozembed.MozEmbed()
        #sets = web.get_settings()
        #sets.set_property('auto-resize-window', True)
        #sets.set_property('enable-universal-access-from-file-uris', True)
        web.load_uri(self.__quote(file))#self.mozBox.load_url(self.__quote(file))

        self.add(web)#self.mozBox)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        #self.set_app_paintable(True)
        #self.set_colormap(self.get_screen().get_rgba_colormap())
        self.set_icon_name('gnome-mime-application-x-shockwave-flash')
        #'flash-player-properties')
        self.set_title('%s ! %sx%s %s' % (
            file[file.rfind('/')+1:],
            header['width'],
            header['height'],
            size2str(header['size']),))
        #self.set_tooltip_text(...
        self.show_all()
        self.set_size_request(int(ow),int(oh))        
        self.set_resizable(False)
        #self.resize(1,1)
        self.connect('delete-event', self.__quit)
        gtk.main()

    def __quit(self, window, event):
        gtk.main_quit()
        return True

    def __quote(self, uri):
        #!get readable uri
        uri = os.path.abspath(uri)
        if uri.startswith('/'):
            try: return urllib.quote('file://'+uri.encode('utf-8'), ':/')
            except: return 'file://' +uri
        return uri
