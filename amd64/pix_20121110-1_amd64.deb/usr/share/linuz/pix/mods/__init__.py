# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os

__dirCache = {}

def listDir(directory, listHiddenFiles=False):
    """ Return a list of tuples (filename, path) with the directory content """
    if directory in __dirCache: cachedMTime, lsDir = __dirCache[directory]
    else:                       cachedMTime, lsDir = None, None

    if os.path.exists(directory): mTime = os.stat(directory).st_mtime
    else:                         mTime = 0

    if mTime != cachedMTime:
        if os.access(directory, os.R_OK | os.X_OK): lsDir = os.listdir(directory)
        else:                                       lsDir = []

        __dirCache[directory] = (mTime, lsDir)

    return [(filename, os.path.join(directory, filename))
        for filename in lsDir if listHiddenFiles or filename[0] != '.']

def listFiles(directory, filters=('.',)):
    files = []
    for (file, path) in sorted(listDir(directory)):
        ext = file[file.rfind('.')+1:].lower()
        if os.path.isfile(path) and ext in filters:
            files.append((file,ext))

    return [file for (file, ext) in sorted(files, key=lambda i: i[1])]
    #def sort_ext(file):
    #    return file[file.rfind('.')+1:].lower()
    #files.sort(key=sort_ext)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def findAttr(txt, att, start=True):
    """ Find an object attribute by the given text """    
    if len(txt) == 1:
        if start and txt[0] == att[0]:
            return True
    elif len(txt) <= len(att):
        if txt in att:
            return True
    return False

def htmlEscape(string):
    """ Replace characters &, <, and > by their equivalent HTML code """
    output = ''
    for c in string:
        if c == '&':   output += '&amp;'
        elif c == '<': output += '&lt;'
        elif c == '>': output += '&gt;'
        else: output += c
    return output

def percentEncode(string):
    """ Percent-encode all the bytes in the given string
        Couldn't find a Python method to do that
    """
    mask  = '%%%X' * len(string)
    bytes = tuple([ord(c) for c in string])
    return mask % bytes

def printableTags(dic):
    """ Return the tags dictionary in a printable format """
    import pprint

    [dic.pop(k) for k in dic.keys() if not pprint.isreadable(dic[k])]
    return dic

def niceString(string):
    """ Replace underscores with spaces and capitalize each word """
    return ' '.join([w.capitalize() for w in string.split('_')])

def str2hash(string):
    """ Return the hash of a string """
    return str(abs(hash(string.lower())))

def sec2str(seconds, showHours=False):
    """ Return a formatted string based on the given duration in seconds """
    hours, seconds   = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds,   60)
    if showHours or hours != 0:
        return '%u:%02u:%02u' % (hours, minutes, seconds)
    else:
        return '%u:%02u' % (minutes, seconds)

def size2str(size):
    """ Turn an integer size value into something human-readable """
    if size >= 1024*1024*1024:
        return "%.1fGB" % (float(size) / (1024*1024*1024))
    elif size >= 1024*1024 * 100:
        return "%.0fMB" % (float(size) / (1024*1024))
    elif size >= 1024*1024 * 10:
        return "%.1fMB" % (float(size) / (1024*1024))
    elif size >= 1024*1024:
        return "%.2fMB" % (float(size) / (1024*1024))
    elif size >= 1024 * 10:
        return "%dKB" % int(size / 1024)
    elif size >= 1024:
        return "%.2fKB" % (float(size) / 1024)
    else:
        return "%dB" % size
