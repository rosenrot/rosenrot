# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#FIXME
import gtk
import os
from gtk import gdk

from mods import listFiles, size2str

EXT   = ('bmp','ico','gif','jpg','jpeg','png','svg','svgz','tif','tiff')
Editr = 'gimp'
gConf = 'gconftool -s /desktop/gnome/background/picture_filename %s -t string'
gSets = 'gsettings set org.gnome.desktop.background picture-uri file://%s'
xConf = 'xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/image-path -s %s'
Trash = '.local/share/Trash/files/%s'

class GtkWindow(gtk.Window):

    app_menu  = None
    linkfile  = None
    slideshow = None
    win_state = 0

    def __init__(self, file):
        self.initWindow(file) if file else self.saveScreenshot()            

    def initWindow(self, file):
        gtk.Window.__init__(self)

        self.image = gtk.Image()
        self.scrollwin = gtk.ScrolledWindow()
        self.scrollwin.add_with_viewport(self.image)
        self.scrollwin.set_shadow_type(gtk.SHADOW_NONE)
        self.viewport = self.scrollwin.get_children()[0]
        self.viewport.set_shadow_type(gtk.SHADOW_NONE)

        self.add(self.scrollwin)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        self.set_icon_name('image')
        self.set_resizable(False)
        self.setImage(file)
        self.show_all()

        for e in (
        gdk.BUTTON_PRESS_MASK,
        gdk.KEY_PRESS_MASK,
        gdk.SCROLL_MASK,):
            self.add_events(e)

        self.connect('button-press-event', self.onButtonPress)
        self.connect('key-release-event', self.onKeyPress)
        self.connect('scroll-event', self.onScrollEvent)
        self.connect('window-state-event', self.onStateEvent)

        self.connect('delete-event', self.__quit)
        gtk.main()

    def __quit(self, window, event):
        gtk.Window.hide(self)

        from gobject import idle_add
        idle_add(gtk.main_quit)
        return True
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def __getPixbuf(self, file):
        if file.endswith('.gif'):
            pix = gdk.PixbufAnimation(file)
            if pix.is_static_image():
                return file, pix.get_static_image(), True
            else:
                return file, pix, False
        else:
            return file, gdk.pixbuf_new_from_file(file), True

    def getPixbuf(self):
        return self.__image[1]

    def getPath(self):
        return self.__image[0]

    def getIsStatic(self):
        return self.__image[2]

    def setImage(self, file):
        """ Render the Pixbuf and show the image """
        self.__image = self.__getPixbuf(file)
        width, height = self.__image[1].get_width(), self.__image[1].get_height()
        self.__image += (width, height)

        if self.win_state: self.__fitToScreen()
        else: self.__fitToWindow()

        self.set_title('%s ! %sx%s %s' % (
            file[file.rfind('/')+1:], width, height,
            size2str(os.stat(file).st_size),))
            #file[file.rfind('.')+1:].upper().replace('JPG','JPEG'),

    def __fitToImage(self):
        sw,sh = gdk.screen_width() *0.85, gdk.screen_height() *0.85
        iw,ih = self.get_size()
        gap = self.scrollwin.get_hscrollbar().get_allocation().height

        pix = self.getPixbuf()
        if iw < pix.get_width() or ih < pix.get_height():
            if pix.get_width()+gap < sw: ow,oh = pix.get_width()+gap,ih
            else: ow,oh = iw,ih
        else: return
        if self.getIsStatic():
            self.image.set_from_pixbuf(pix)
        else:
            self.image.set_from_animation(pix)

        if pix.get_width() <= ow: hpolicy = gtk.POLICY_NEVER
        else: hpolicy = gtk.POLICY_AUTOMATIC
        if pix.get_height() <= oh: vpolicy = gtk.POLICY_NEVER
        else: vpolicy = gtk.POLICY_AUTOMATIC
        self.scrollwin.set_policy(hpolicy, vpolicy)

        self.set_size_request(int(ow),int(oh))
        del pix

    def __fitToWindow(self):
        pix = self.getPixbuf()
        iw,ih = pix.get_width(), pix.get_height()
        sw,sh = gdk.screen_width() *0.85, gdk.screen_height() *0.85

        if iw < 256: ow,oh = 256, 256*ih/iw if ih > 256 else 256         
        elif iw > sw: ow,oh = sw, ih*sw/iw
        else: ow,oh = iw,ih
        if oh > sh: ow,oh = iw*sh/ih, sh

        if self.getIsStatic():
            if ow < pix.get_width() or oh < pix.get_height():
                pix = pix.scale_simple(int(ow),int(oh), gdk.INTERP_BILINEAR)
            self.image.set_from_pixbuf(pix)
        else:
            self.image.set_from_animation(pix)

        self.scrollwin.set_policy(gtk.POLICY_NEVER, gtk.POLICY_NEVER)
        self.set_size_request(int(ow),int(oh))
        del pix

    def __fitToScreen(self):
        pix = self.getPixbuf()
        iw,ih = pix.get_width(), pix.get_height()
        sw,sh = gdk.screen_width(), gdk.screen_height()
        ow,oh = ow,oh = iw*sh/ih, sh

        if ow > sw: ow,oh = sw, oh*sw/ow
        if self.getIsStatic():
            if ow != iw or oh != ih:
                pix = pix.scale_simple(int(ow),int(oh), gdk.INTERP_BILINEAR)
            self.image.set_from_pixbuf(pix)
        else:
            self.image.set_from_animation(self.getPixbuf())

        self.scrollwin.set_policy(gtk.POLICY_NEVER, gtk.POLICY_NEVER)
        self.set_resizable(False)
        del pix
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onButtonPress(self, widget, event):
        if event.button == 1 and event.type == gdk._2BUTTON_PRESS:
            if self.win_state:
                self.set_resizable(False)
                self.unfullscreen()
            else:
                self.set_resizable(True)
                from gobject import idle_add
                idle_add(self.fullscreen)
        elif event.button == 2 or event.button == 0:
            if self.getIsStatic():
                self.__fitToImage() \
                if self.image.get_pixbuf() != self.getPixbuf() \
                else self.__fitToWindow()
        elif event.button == 3:
            self.onMenuPopup(event.get_time())

    def onMenuPopup(self, time):
        if not self.app_menu:
            self.app_menu = self.__setMenu()
        self.app_menu.show_all()
        self.app_menu.popup(None, None, None, 3, time, 0)

    def __setMenu(self):
        from gettext import gettext as _
        menu = gtk.Menu()

        fit = gtk.ImageMenuItem(gtk.STOCK_ZOOM_100)#_FIT)#_100)
        fit.connect('activate', lambda w: self.emit('button-press-event',
            gdk.Event(gdk.BUTTON_PRESS)) )
        menu.append(fit)
        edit = gtk.ImageMenuItem(gtk.STOCK_EDIT)
        edit.set_sensitive(os.path.exists('/usr/bin/%s' % Editr))
        edit.connect('activate', lambda w: self.openWith())
        menu.append(edit)
        save = gtk.ImageMenuItem(gtk.STOCK_SAVE_AS)
        save.connect('activate', lambda w: self.saveImage())
        menu.append(save)
        setbg = gtk.ImageMenuItem(_('Set as background'))
        setbg.set_image(gtk.image_new_from_icon_name(
            'desktop', gtk.ICON_SIZE_MENU))
        setbg.connect('activate', lambda w: self.asBackground())
        menu.append(setbg)

        menu.append(gtk.SeparatorMenuItem())
        close = gtk.ImageMenuItem(gtk.STOCK_CLOSE)
        close.connect('activate', lambda w: self.__quit(self, None))
        menu.append(close)

        return menu

    def onKeyPress(self, win, event):
        key = gdk.keyval_name(event.keyval)
        if key == 'Delete':
            file = self.getPath()
            self.__skipImage(+1)
            os.rename(file, os.path.join(os.path.expanduser('~'),
                Trash % os.path.basename(file)))
            if file == self.getPath():
                self.__quit(self, None)
        elif key == 'Escape':
            self.unfullscreen() if self.win_state else self.__quit(self, None)
        elif key == 'Right':
            self.__skipImage(+1)
        elif key == 'Left':
            self.__skipImage(-1)
        elif key == 'space':
            self.emit('button-press-event', gdk.Event(gdk.BUTTON_PRESS))

    def onScrollEvent(self, widget, event):
        if event.direction == gdk.SCROLL_UP: self.__skipImage(+1)
        else: self.__skipImage(-1)

    def __skipImage(self, position):
        path = self.getPath()
        slash = path.rfind('/')+1
        dir,file = path[:slash], path[slash:]
        files = listFiles(dir, EXT)
        for n,i in enumerate(files):
            if file == i:
                try: file = files[n+position]
                except: file = files[0]
                self.setImage(os.path.join(dir, file))
                break
        #return True

    def onStateEvent(self, widget, event):#TODO
        #import gobject
        self.win_state = event.new_window_state
        if self.win_state == 0:
            self.viewport.modify_bg(gtk.STATE_NORMAL,
                self.get_style().bg[gtk.STATE_NORMAL])
            self.__fitToWindow()
            #if self.slideshow != None:
            #    gobject.source_remove(self.slideshow)
            #self.slideshow = None
        elif self.win_state == gdk.WINDOW_STATE_FULLSCREEN:
            self.viewport.modify_bg(gtk.STATE_NORMAL, gdk.color_parse('#000'))
            self.__fitToScreen()
            #if self.slideshow == None:
            #    self.slideshow = gobject.timeout_add(5000, self.__skipImage,+1) 
        #elif event.new_window_state == gdk.WINDOW_STATE_MAXIMIZED:
        #    self.__fitToWindow()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def openWith(self):
        import subprocess
        try:
            subprocess.Popen([Editr, self.getPath()])
        finally:
            self.__quit(self, None)

    def asBackground(self):
        file = os.path.join(os.path.expanduser('~'), '.cache', 'pix')
        if self.linkfile == None:
            from shutil import copyfile
            self.linkfile = copyfile #os.symlink
            self.__setConf(file)
        #if os.path.exists(file): os.remove(file)
        self.linkfile(self.getPath(), file)

    def __setConf(self, file):
        import subprocess
        for cmd in (gConf, gSets, xConf):
            try:
                subprocess.call(cmd % file, shell=True)
            except Exception, err:
                print err

    def saveImage(self):
        pix = self.getPixbuf()
        if not self.getIsStatic():
            pix = pix.get_static_image()
        file = self.__fileChooser(self.getPath())
        if not file:
            return
        elif file.endswith('.jpg'):
            pix.save(file, 'jpeg', {'quality':'100'})
        elif file.endswith('.png'):
            pix.save(file, 'png')

    def saveScreenshot(self):
        file = os.path.join(os.path.expanduser('~'), 'screenshot.png')
        width, height = gdk.screen_width(), gdk.screen_height()
        pix = gdk.Pixbuf.get_from_drawable(
            gdk.Pixbuf(gdk.COLORSPACE_RGB, True, 8, width, height),
            gdk.get_default_root_window(),
            gdk.colormap_get_system(),
            0, 0, 0, 0, width, height)

        self.__image = file, pix, True      
        self.saveImage()

    def __fileChooser(self, file):
        dlg = gtk.FileChooserDialog(
            self.__stockLabel(gtk.STOCK_SAVE_AS),
            self, gtk.FILE_CHOOSER_ACTION_SAVE, (
            gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
            gtk.STOCK_SAVE, gtk.RESPONSE_OK) )
        dlg.set_do_overwrite_confirmation(True)
        dlg.set_select_multiple(False)
        dlg.set_current_folder(os.path.dirname(file))
        dlg.set_current_name(os.path.basename(file))

        file = None
        if dlg.run() == gtk.RESPONSE_OK:
            file = dlg.get_filename()
        dlg.destroy()
        return file

    def __stockLabel(self, stock_id):
        return gtk.stock_lookup(stock_id)[1].replace('_', '')
